DROP TABLE IF EXISTS `seo_config`;
create table `seo_config` (
`k` varchar(32) NOT NULL,
`v` text NULL,
PRIMARY KEY  (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `seo_config` VALUES ('DB_version', '1.9');
INSERT INTO `seo_config` VALUES ('user', 'admin');
INSERT INTO `seo_config` VALUES ('pwd', '123456');
INSERT INTO `seo_config` VALUES ('404', '<center><h1>404错误页代码</center></h1>');
INSERT INTO `seo_config` VALUES ('button', '点此进入|点此前往|快速进入|快速前往|继续前往|继续进入|加盟我们|立即打开|立即前往|立即下単|立即进入|立即查看|立刻打开|立刻前往|立刻下単|立刻进入|立刻查看|马上打开|马上前往|马上下単|马上进入|马上查看|点击打开|点击前往|点击下単|点击进入|点击查看|点我打开|点我前往|点我下単|点我进入|点我查看|进入官网|查看平台|前往官网|前往打开|前往下単|前往查看|联系我们');
INSERT INTO `seo_config` VALUES ('tiaozhuan', '关闭');
INSERT INTO `seo_config` VALUES ('sitename', 'SEO单页站群系统');
INSERT INTO `seo_config` VALUES ('title', '网站名称');
INSERT INTO `seo_config` VALUES ('keywords', '网站关键词');
INSERT INTO `seo_config` VALUES ('description', '网站描述');
INSERT INTO `seo_config` VALUES ('qq', '2646906096');
INSERT INTO `seo_config` VALUES ('xiadanurl', 'https://baidu.cn');
INSERT INTO `seo_config` VALUES ('symuban', '0');
INSERT INTO `seo_config` VALUES ('footer', '首页底部代码');
INSERT INTO `seo_config` VALUES ('baidu_number', '2');
INSERT INTO `seo_config` VALUES ('intercept', '定时炸弹|天天干|DNS|床垫|儿童|慈善|中职|机车|印刷|中学|酒店|卫生|病友|贷款|法律|法规|跑腿|妈咪|母婴|公务员|许可证|刑事|律师|超市|机场|康复|税务|银行|政府|医药|安全防|搜狗搜|红酒|妈妈|保险|提示|报警|民医院|医疗|防癌|加载中|共和国|航空|幼教|幼师|法院|人民共|眼镜|脸识别|门禁|新能源|汽车|药业|性别|做爱|国家|阿里云|腾讯云|执照|财务|记账|抵押|房子|地产|房抵|养老|百度一下|注册大厅|???|请续费|中国|看黄|公安|体育|彩票|停放|买球|正规官|无法正常|世界杯|发生错误|亚娱|亚州|已到期|续费提醒|域名到期|产精|娱乐APP|超清无码|亚博|禁止访问|访问验证|找不到文件或目录|站点已暂停|服务器错误|没有找到站点|页面不存在|新唐人|大纪元|阿波罗|法轮功|伊人|大香蕉|美女上门|上门技师|威尼斯|色狗|做爰|成人|看片|草莓视频|毛片|亚洲|色图|偷拍视频|亚搏|万博|大禁书|陳破空|香港马会|阴道|露阴|撸管|波多野|成人小说|龙虎群|老虎城|足彩比分|即時比分|足球比分|即时比分|国产|404 N|站点创建成功|建设中|过期|平台注');
INSERT INTO `seo_config` VALUES ('bei_strlen', '30');

CREATE TABLE `seo_article` ( 
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT
,`title` VARCHAR(225) NOT NULL
,`keywords` VARCHAR(225) NOT NULL
,`description` VARCHAR(225) NOT NULL
,`button` TEXT NOT NULL
,`tximg` VARCHAR(999) NOT NULL
,`count` INT(11) NOT NULL
,`addtime` DATETIME NOT NULL
,`img` VARCHAR(999) NOT NULL
,`juzi` varchar(9999)  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
,`chengyu` VARCHAR(999) NOT NULL
,`muban` VARCHAR(225) NOT NULL
,`xiadan_url` VARCHAR(225) NOT NULL
,`active` VARCHAR(99) NOT NULL  DEFAULT '1'
,PRIMARY KEY( `id`)
,INDEX( `title`)
,INDEX(`addtime`)
) ENGINE = InnoDB  DEFAULT CHARSET=utf8;


CREATE TABLE `seo_classlist` (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT
,`host` VARCHAR(225)  NOT NULl
,`addtime` DATETIME NOT NULL
,`list` varchar(9999)  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL
,`sort` INT(11)  NULL
,`tuisong_id` INT(9) NOT NULL
,`tuisong_count` VARCHAR(999)  NOT NULl
,`js` VARCHAR(999)  NOT NULl
,UNIQUE( `id`)
,PRIMARY KEY(`host`)
) ENGINE = InnoDB  DEFAULT CHARSET=utf8;


CREATE TABLE `seo_tuisong` (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT
,`name` VARCHAR(225)  NOT NULL
,`addtime` DATETIME NOT NULL
,`baidu_api` VARCHAR(225) NOT NULL
,`sm_api` VARCHAR(225) NOT NULL
,`bing_api` VARCHAR(225) NOT NULL
,`num` INT(11)  NULL
,`sm_daily` INT(9)   NOT NULl
,`bing_daily` INT(9)   NOT NULl
,`baidu_daily` INT(9)   NOT NULl
,PRIMARY KEY( `id`)
,INDEX(`name`)
) ENGINE = InnoDB  DEFAULT CHARSET=utf8;