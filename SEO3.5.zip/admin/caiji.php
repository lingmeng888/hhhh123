<?
include("../includes/common.php");
if($islogin!=1)exit("<script language='javascript'>window.location.href='./login.php';</script>");

header('Access-Control-Allow-Origin:*'); // *代表允许任何网址请求
header('Content-type: application/json');

$mod=isset($_GET['mod'])?($_GET['mod']):exit(json(202,"msg","mod参数不能为空"));
$url=$_GET['url']!=null?(trim($_GET['url'])):exit(json(202,"msg","网址不能为空"));
if(strpos($url,'http')===false)exit(json(202,"msg","请填写完整的网址，带上http"));
if($mod=='caiji'){
$data=@json_decode(caiji($url),true);
if($data['code']==200){ exit(json(200,'msg',$data['msg']));
}else{ exit(json(202,'msg',$url."-采集失败<br>".trim(stripslashes($data['msg'])))); } }


elseif($mod=='caiji2'){
setcookie("batch", $url, time()+360000);//缓存100小时
if(strpos($url,'-')===false){ exit(json(202,"msg","请检查采集参数是否正确，必须带有-")); }
$url=str_replace(['（','）'],['(',')'],$url);
$url2 = preg_replace('/\(.*?\)/', '||', $url);
preg_match_all("/\((.*?)\)/",$url,$url);

if($url[1][0]==null||$url2==null){ exit(json(202,"msg","请检查采集地址是否正确")); }
$urls=explode('-',$url[1][0]);
if($urls[0]=='0'||$urls[1]=='0')exit(json(202,"msg","采集参数不能设置为0"));
if(!$urls[0]||!$urls[1]||!preg_match("/^[1-9][0-9]*$/",$urls[0])||!preg_match("/^[1-9][0-9]*$/",$urls[1])){ 
exit(json(202,"msg","请检查采集参数是否正确")); }

$cg=0;
for ($x=$urls[0]; $x<=$urls[1]; $x++) {
$url3=str_replace("||",$x,$url2); 
$caiji=json_decode(caiji($url3),true);
if($caiji['code']==200){ $cg++; } 
} 
exit(json(200,"msg","采集成功：".round($cg)."<br>失败次数：".round($urls[1]-($urls[0]-1)-$cg)));
}


elseif($mod=='caiji3'){
setcookie("Increasing", $url, time()+360000);//缓存100小时
setcookie("status",'挂机', time()+360000);//缓存100小时
if(strpos($url,'+')===false){ exit(json(202,"msg","请检查递增采集参数是否正确，必须带有+")); }
$url=str_replace(['（','）'],['(',')'],$url);
$url2 = preg_replace('/\(.*?\)/', '||', $url);
preg_match_all("/\((.*?)\)/",$url,$url);
if($url[1][0]==null||$url2==null){ exit(json(202,"msg","请检查递增采集地址是否正确")); }
$urls=explode('+',$url[1][0]);
if($urls[0]=='0'||$urls[1]=='0')exit(json(202,"msg","采集参数不能设置为0"));
if(!$urls[0]||!$urls[1]||!preg_match("/^[1-9][0-9]*$/",$urls[0])||!preg_match("/^[1-9][0-9]*$/",$urls[1])){ 
exit(json(202,"msg","请检查采集参数是否正确")); }
$zsnum=round($urls[0]+$urls[1]);

$cg=0;
for ($x=$urls[0]; $x<=$zsnum; $x++) {
$url3=str_replace("||",$x,$url2); 

$value="({$x}+".$urls[1].")";
$Increasing=str_replace("||",$value,$url2);   
setcookie("Increasing", $Increasing, time()+360000);//缓存100小时 

$caiji=json_decode(caiji($url3),true);
if($caiji['code']==200){ $cg++; }} 
exit(json(200,"msg","采集成功：".round($cg)."<br>失败次数：".round($urls[1]-$cg)));
}