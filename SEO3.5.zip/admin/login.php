<?
include_once("../includes/common.php");
$user=zhuru($_POST['user']);
$pwd=zhuru($_POST['pwd']);
if($user && $pwd){ 
if($user===$config['user'] && $pwd===$config['pwd']) {
$session=md5($user.$pwd.$password_hash);    
setcookie("admin_token", $session, time() + 604800);     
swal(1,'登录成功','登陆管理中心成功','好的，知道了','./',15); 
}else{ swal(2,'温馨提示','账号或密码不正确','好的，知道了');  } 

}elseif(isset($_GET['logout'])){
	setcookie("admin_token", '', time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	swal(3,'温馨提示','您已成功注销本次登陆!','知道了','./login.php');  
}elseif($islogin==1){
	@header('Content-Type: text/html; charset=UTF-8');
	swal(1,'系统提示','您已登陆！','好的','./',15); }
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
  <title>站长登录 - <?=$config['sitename']?></title>
  <link href="//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="//lib.baomitu.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>

  <script src="//lib.baomitu.com/modernizr/2.8.3/modernizr.min.js"></script>
  <!--[if lt IE 9]>
    <script src="//lib.baomitu.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="//lib.baomitu.com/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>
<div class="dowebok">
	<div class="container-login100">
		<div class="wrap-login100">
			<div class="login100-pic js-tilt" data-tilt>
				<img src="images/img-01.png" alt="IMG">
              
			</div>
			

			<form class="login100-form validate-form" method="post" >
				<span class="login100-form-title"><?=$config['sitename']?>-站长登陆
				</span>

				<div class="wrap-input100 validate-input">
					<input type="text" name="user" value="" class="input100" required="required" placeholder="用户名">
					
                    <span class="focus-input100"></span> 
					<span class="symbol-input100">
						<i class="fa fa-user" aria-hidden="true"></i>
					</span>
				</div>

				<div class="wrap-input100 validate-input">
					<input type="password" name="pwd" class="input100" required="required" placeholder="密码">
					
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-lock" aria-hidden="true"></i>
					</span>
				</div>
				
			<!--登陆验证开始
			
				<div class="ext-center p-t-10">
                  <div id="captcha" style="margin: auto;"><div id="captcha_text">
                正在加载验证码</div>
              <input type="hidden" name="captcha_type" value=""/>
			</div> 
              
			   登陆验证结束!-->
                  
                   
				<div class="container-login100-form-btn">
					<button class="login100-form-btn" type="submit">立即登陆
					</button>
				</div>

              
				<div class="text-center p-t-12"><a onclick="alert('请在数据库里找conf数据表，自行查看即可')" class="txt2">忘记密码？</a>
								</div>

							</form>
			
</div></div></div>
<script src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
<script src="//lib.baomitu.com/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="//lib.baomitu.com/layer/2.3/layer.js"></script>

</body>
</html>