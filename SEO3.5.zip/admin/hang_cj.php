<?
include("../includes/common.php");
if($islogin!=1)exit("<script language='javascript'>window.location.href='./login.php';</script>");

$file='hang_cj.txt';
$mod=$_GET['mod']; if($mod=='hang_caiji'){
header("Content-type:text/html;charset=utf-8");
header('Access-Control-Allow-Origin:*'); // *代表允许任何网址请求

$url=$_POST['url']!=null?(trim($_POST['url'])):exit(json(202,"msg","网址不能为空！一行一个 请看教程！"));
if(strpos($url,'http')===false)exit(json(202,"msg","请填写完整的网址，带上http"));

$url=array_unique(explode("\n", $url));
$url=implode("\n",$url); //数组指定格式拼接

$urls=trim(explode("\n",$url)[0]);

$url=trim(explode("\n", $url,2)[1]);
$url=trim(trim($url,"\n"),"\r");
@file_put_contents($file,$url);

setcookie("hang_status",'行采挂机', time()+360000);//缓存100小时
 exit(caiji($urls)); }

$title='按行批量采集'.' - '.$config['sitename'];
include_once'head.php';?>

<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;"><div class="block">
<div class="block-title"><h3 class="panel-title">按行批量采集网址TDK</h3></div>
<div class="">


<textarea class="form-control" type="text" name="url"  rows="15"  placeholder="一行一个网址，不懂就看下方提示" data-toggle="tooltip" data-original-title="一行一个，不懂就看下方提示"><?=(file_exists($file)?file_get_contents($file):null);?></textarea></div><br>
一行一个，格式如下：<br>
网址1<br>
网址2<br>
网址3<br>
提示：其它信息无需填写，会自动生成，重复的标题自动过滤不添加
<hr>
<input type="submit" name="submit" value="确定批量采集"  onclick="hang_caiji()" class="btn btn-primary btn-block"/><hr/>


<div class="block"><a class="btn btn-block" href="article.php"><i class="fa fa-mail-reply-all"></i>  返回文章列表</a></div>

	</div>


</div>
</div>   

<script src="//lib.baomitu.com/layer/3.1.1/layer.js"></script> 
<script>
function empty(e) { //判断是否为空
  switch (e) {
    case "":
    case 0:
    case "0":
    case null:
    case false:
    case undefined:
      return true;
    default:
      return false; }  }

function hang_caiji() {
var urls = document.getElementsByName('url')[0].value;
if(empty(urls)){ layer.alert('网址不能为空', {icon:2}); clearCookie('hang_status'); return shuaxin(2); }

layer.msg('努力自动行采中...请稍等', {icon:1,time:300000000
,btn: ['立即关闭自动行采'] 
,yes: function(index,layero){ clearCookie('hang_status'); return shuaxin(0);}
});
	$.ajax({
		type : 'POST',
		url : '?mod=hang_caiji',
      data : {url:urls}, 
		dataType : 'json',
		success : function(data) {

if(data.code == 200){
layer.alert(data.msg, {icon:1
,btnAlign: 'c'
,btn: ['立即关闭自动采集','继续采集无视即可'] 
,yes: function(index,layero){ clearCookie('hang_status'); return shuaxin(0); }
,btn2: function(index, layero){ return shuaxin(0);  }
}); return shuaxin(3);
}else{ layer.alert(data.msg,{icon:2}); return shuaxin(2); }

}, error:function(data){
layer.msg('请稍后重试');  return shuaxin(2);
} });}


<?if(isset($_COOKIE["hang_status"])&&$_COOKIE["hang_status"]=='行采挂机'){?>	
window.setTimeout(function() { return hang_caiji()},1000);  //每隔2秒执行一次行
<?}?>


function shuaxin(m) {
setTimeout(function(){ window.location.reload(); },(1000*m) ); }

//设置cookie
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires; }

//清除cookie  
function clearCookie(name) {  
    setCookie(name, "", -1);  
}  
</script>