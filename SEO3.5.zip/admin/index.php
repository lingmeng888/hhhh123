<?
include("../includes/common.php");

if($islogin!=1)exit("<script language='javascript'>window.location.href='./login.php';</script>");
if($_GET['clean']=='tongji'){ unlink(SYSTEM_ROOT.'article.tongji.php');  exit(swal(1,'小提示','article.tongji.php，统计缓存清理成功！','我知道了','./'));  }

$title='管理首页'.' - '.$config['sitename'];
include 'head.php'; ?>
<style>
@media (max-width:767px){
.showcountl{padding-right: 5px;}
.showcountr{padding-left: 5px;}
}
</style>
		

<div class="col-xs-6 col-lg-4 showcountl">
    
	<a href="javascript:void(0)" class="widget">
	<div class="widget-content widget-content-mini text-right clearfix">
		<div class="widget-icon pull-left themed-background">
			<i class="fa fa-list-ol text-light-op"></i>
		</div>
		<h2 class="widget-heading h3">
		    
		<strong><?=$jr_num?></strong>
		</h2>
		<span class="text-muted">今日文章</span>
	</div>
	</a>
</div>
<div class="col-xs-6 col-lg-4 showcountr">
	<a href="javascript:void(0)" class="widget">
	<div class="widget-content widget-content-mini text-right clearfix">
		<div class="widget-icon pull-left themed-background-success">
			<i class="fa fa-first-order text-light-op"></i>
		</div>
		<h2 class="widget-heading h3 text-success">
		<strong><?=$zr_num?></strong>
		</h2>
		<span class="text-muted">昨日文章</span>
	</div>
	</a>
</div>
<div class="col-xs-6 col-lg-4 showcountl">
	<a href="javascript:void(0)" class="widget">
	<div class="widget-content widget-content-mini text-right clearfix">
		<div class="widget-icon pull-left themed-background-warning">
			<i class="fa fa-briefcase text-light-op"></i>
		</div>
		<h2 class="widget-heading h3 text-warning">
		<strong><?=round($zongshu)?></strong>
		</h2>
		<span class="text-muted">文章累计</span>
	</div>
	</a>
</div>
</div>

<? if($yxsq['head_advert']!=null){?>
<div class="alert alert-warning  alert-dismissable text-center">
<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true"style="color: black"><i class="fa fa-times-circle"></i></span></button><?=$yxsq['head_advert']?></div><?}?>


<? $ht_mulu=end(explode('/',dirname(__FILE__)));?>

<div class="alert alert-info alert-dismissable text-center">
<? if($ht_mulu=='admin'){?><i class="fa fa-free-code-camp"></i>&nbsp;提示：后台目录建议修改一下，避免被他人爆破！<br><?}?>
<i class="fa fa-free-code-camp"></i>&nbsp;为防止数据过大统计太卡，直接启用缓存统计！<a href="?clean=tongji" class="btn btn-danger btn-xs"><i class="fa fa-arrow-right"></i>清理统计缓存</a><br>
<? if($zongshu<=10000){?><i class="fa fa-free-code-camp"></i>&nbsp;提示：本程序技巧特殊，一般需要至少上万的文章才能支撑完美运行！<br><?}?>
<? if($zongshu>=2000000){?><i class="fa fa-free-code-camp"></i>&nbsp;提示：检测到您的文章过多 数据库挺大，请定期备份数据,避免数据丢失！<br><?}?>
<i class="fa fa-copyright"></i>本程序可多个站点绑定同一个目录+数据库使用，且每个站点所展示的单页内容都不一样，不用担心内容重复百度不收录！
</div>

	<div class="widget">

		<div class="widget-content border-bottom"><i class="fa fa-cloud text-dark push"></i> 采集网站</div>
		<div class="widget-content widget-content-full-top-bottom border-bottom">
			
	<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="input-group"><div class="input-group-addon">单条采集</div>
<input class="form-control" type="text" name="url" value="" placeholder="请输入网址" data-toggle="tooltip" data-original-title="请输入网址">
<div class="input-group-addon" onclick="caiji1()">抓取</div>
</div>
<? if($config['zuci']==1){ echo'<pre><i class="fa fa-bullhorn"></i>自从组词功能开启中，可能会影响采集功能的性能！</pre>'; }?>
</div>
<hr>
	<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="input-group"><div class="input-group-addon">批量采集</div>
<input class="form-control" type="text" name="url2" value="<?=$_COOKIE["batch"]?>"  placeholder="请输入网址" data-toggle="tooltip" data-original-title="请输入网址">
<div class="input-group-addon" onclick="caiji2()">抓取</div>
</div>
<pre>
<?if(isset($_COOKIE["batch"])){?><i class="fa fa-bullhorn"></i>检查到您上次批量采集的地址是：<font color=red><?=$_COOKIE["batch"]?></font><br><?}?>
<i class="fa fa-bullhorn"></i>使用实例：填写http://baidu.com/qq/(1-3).html，挨个采集从/qq/1.html采集到3.html，批量采集数量请勿太大，不然较慢！记得使用：(1-3)，以此内推</pre>
</div>


<hr>
	<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="input-group"><div class="input-group-addon">递增采集</div>
<input class="form-control" type="text" name="url3" value="<?=$_COOKIE["Increasing"]?>"  placeholder="请输入网址" data-toggle="tooltip" data-original-title="请输入网址">
<div class="input-group-addon" onclick="caiji3()">抓取</div>
</div>
<pre>
<?if(isset($_COOKIE["Increasing"])){?><i class="fa fa-bullhorn"></i>检查到您上次递增采集的地址是：<font color=red><?=$_COOKIE["Increasing"]?></font>&nbsp;<a onclick="clearCookie('status'); window.location.reload();" class="btn btn-xs btn-info">关闭递增</a><br><?}?>
<i class="fa fa-bullhorn"></i>使用实例：填写http://baidu.com/qq/(100+3).html，会自动从100采集到103后自动刷新页面，再从103采集到106，以此内推，挂机自动递增采集</pre>
</div>

<br>

</div></div>


<div class="block">

<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title">
<a data-toggle="collapse" data-parent="#shuoming1" href="#shuoming1" aria-expanded="false" class="collapsed">
帮助1<i class="fa fa-fw fa-arrow-circle-right"></i>一些常规疑问解答？
</a></h4></div>
<div id="shuoming1" class="panel-collapse collapse" style="height: 0px;" aria-expanded="false"><div class="panel-body">
    
<font color='black'><p style="text-align:left;">Ps：本站群系统起来几率很高，因为可多个域名同时使用，看个人所在行业，有些行业投资50个域名，一般至少起来几个，都能达到一本万利！
</p><hr>
    
<font color='black'><p style="text-align:left;">1问：如何增加单页模板？<br>
<font color='black'>1答：单页模板目录：template，在里面新建一个文件夹，然后文件夹里新建index.php文件</p><hr>
    
<font color='black'><p style="text-align:left;">2问：为什么没有写后台蜘蛛来访列表？<br>
2答：没啥用的 很多人采集你网站内容都是伪造的蜘蛛来访，看实际权重就行了</p><hr>

<font color='black'><p style="text-align:left;">3问：为什么我文章单页访问了没效果？<br>
3答：为了防止文章单页内容重复，所以本程序的ID算法特殊，需要几千以上的大量文章支撑，不然就是404提示！</p><hr>

<font color='black'><p style="text-align:left;">4问：做SEO,域名这些有没有好的推荐？<br>
4答：建议用惫案域名，据统计没有惫案的域名 现在百度几乎不会给什么排名；还有查下域名建站记录，最好是近几年都有正规的建站历史；还有看下域名的收录情况等；友链和反链多的域名也一般也不错，如果没有的话可自己花点钱买点友链即可！
<br>给个小建议：直接批量上几十个站点，肯定会有那么几个起来的，就看你所在行业能不能做到一本万利了(Ds行业几乎可以)</p><hr>

</font></div></div> </div>

<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title">
<a data-toggle="collapse" data-parent="#shuoming4" href="#shuoming4" aria-expanded="false" class="collapsed">
帮助2<i class="fa fa-fw fa-arrow-circle-right"></i>不挂访问计划任务还能推送百度和神马？
</a></h4></div>
<div id="shuoming4" class="panel-collapse collapse" style="height: 0px;" aria-expanded="false"><div class="panel-body">
<font color='black'><p style="text-align:left;">是的，这也是本程序的一个功能特点，您只需将推送接口模板配置好，本程序只要有用户访问便可实现自动推送！
<hr>功能原理：将以前的访问计划 改写成用户访问，并且不会造成程序卡顿！且蜘蛛来访时会更加流畅！这样也方便大家 不用再像以前一样还要去挨个域名去挂访问计划任务了！
<hr>如果你觉得不放心，可手动访问：域名/<?=$yx_mulu?>baidu.php，查看推送效果！
</p></font></div></div> </div>


<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title">
<a data-toggle="collapse" data-parent="#shuoming3" href="#shuoming3" aria-expanded="false" class="collapsed">
帮助3<i class="fa fa-fw fa-arrow-circle-right"></i>如何访问一次网站，生成多个随机组词文章？
</a></h4></div>
<div id="shuoming3" class="panel-collapse collapse" style="height: 0px;" aria-expanded="false"><div class="panel-body">
<font color='black'>在网站根目录生成一个php文件，里面放入以下代码，然后访问即可<br>
<pre>&lt;? include_once("includes/common.php");
$num=100; //每次访问生成多少文章
for ($x=0; $x<=$num; $x++) { tdk_sheng(); }</pre>
</font></div></div> </div>



</div>


	<div class="widget">
<div class="widget-content border-bottom">
<center><span id="time"><?=date("Y-m-d H:i:s")?></span></center>
<?=$yxsq['msg']?>
</div>
</div>
<script type="text/javascript">
function time(){
var vWeek,vWeek_s,vDay;
vWeek = ["星期天","星期一","星期二","星期三","星期四","星期五","星期六"];
var date =  new Date();
year = date.getFullYear();
month = date.getMonth() + 1;
day = date.getDate();
hours = date.getHours();
minutes = date.getMinutes();
seconds = date.getSeconds();
vWeek_s = date.getDay();
document.getElementById("time").innerHTML = year + "年" + month + "月" + day + "日" + "\t" + hours + ":" + minutes +":" + seconds + "\t" + vWeek[vWeek_s] ;

};
setInterval("time()",1000);

</script>
<script>
function caiji1() {
var url = document.getElementsByName('url')[0].value;

layer.msg('努力单条采集中...请稍等', {time: 300000000});    
	$.ajax({
		type : 'GET',
		url : 'caiji.php?mod=caiji',
      data : {url:url}, 
		dataType : 'json',
		success : function(data) {
if(data.code == 200){
layer.alert(data.msg, {icon:1} ,function(){ window.location.reload(); } );
}else{
layer.alert(data.msg,{icon:2}//,function(){ window.location.reload() }
); 
}  
		},
		error:function(data){
			layer.msg('请稍后重试');
			return false;
		}
	});}
	
	
function caiji2() {
var url2 = document.getElementsByName('url2')[0].value;

layer.msg('努力批量采集中...请稍等', {time: 300000000});    
	$.ajax({
		type : 'GET',
		url : 'caiji.php?mod=caiji2',
      data : {url:url2}, 
		dataType : 'json',
		success : function(data) {
if(data.code == 200){
layer.alert(data.msg, {icon:1} ,function(){ window.location.reload(); } );
}else{
layer.alert(data.msg,{icon:2},function(){ window.location.reload(); }
); 
}  
		},
		error:function(data){
			layer.msg('请稍后重试');
			return false;
		}
	});}
	
	
	
	function caiji3() {
var url3 = document.getElementsByName('url3')[0].value;

layer.msg('努力递增采集中...请稍等', {icon:1,time:300000000
,btnAlign:'c',btn: ['立即关闭自动递增采集']
,yes: function(index,layero){ clearCookie('status'); return shuaxin(0);}
});    
	$.ajax({
		type : 'GET',
		url : 'caiji.php?mod=caiji3',
      data : {url:url3}, 
		dataType : 'json',
		success : function(data) {
if(data.code == 200){
layer.alert(data.msg, {icon:1 ,btnAlign:'c',btn: ['立即关闭自动递增采集','继续递增采集 无视即可'] 
,yes: function(index,layero){ clearCookie('status'); return shuaxin(0);  }
,btn2: function(index, layero){ return shuaxin(0);  }
});
return shuaxin(2.8);

}else if(data.code == 202){ layer.alert(data.msg,{icon:2});
}else{  layer.alert(data.msg, {icon:2}); return shuaxin(2); }
}, error:function(data){ layer.msg('请稍后重试'); return shuaxin(0);}
});}

<?if(isset($_COOKIE["status"])&&$_COOKIE["status"]=='挂机'){?>	
window.setTimeout(function() { return caiji3()},3000);  //每隔8秒执行一次行
<?}?>

function shuaxin(m) {
setTimeout(function(){ window.location.reload(); },(1000*m) ); }

//设置cookie
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires; }

//清除cookie  
function clearCookie(name) {  setCookie(name, "", -1);  }  
	</script>

</body>
</html>