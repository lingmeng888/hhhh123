<? if (strpos($_SERVER['PHP_SELF'],'template')!== false&&strpos($_SERVER['PHP_SELF'],'index.php')!== false){
  header("HTTP/1.1 404 Not Found");
  header("Status: 404 Not Found");  exit;} ?>
<!DOCTYPE html>
<html lang="en"><!--<![endif]--><head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	
	<title><?=$user['title']?></title>
  	<meta name="keywords" content="<?=$user['keywords']?>">
	<meta name="description" content="<?=$user['description']?>">
   <meta content="<?=$config['sitename']?>" name="author">
	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<link href="<?=$siteurl.$yx_mulu?>template/16/assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/16/assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/16/assets/css/animate.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/16/assets/css/style.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/16/assets/css/style-responsive.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/16/assets/css/blue.css" id="theme" rel="stylesheet">
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="<?=$siteurl.$yx_mulu?>template/16/assets/js/pace.min.js"></script>
	<!-- ================== END BASE JS ================== -->

	 <!-- ================== 百度自动推送================== -->
 <script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
	 <!-- ================== 百度自动推送================== -->
</head>
<body data-spy="scroll" data-target="#header-navbar" data-offset="51" class=" pace-done"><div class="pace  pace-inactive hide"><div class="pace-progress" data-progress-text="100%" data-progress="99" style="width: 100%;">
  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>
    <!-- begin #page-container -->
    <div id="page-container" class="fade in">
        <!-- begin #header -->
        <div id="header" class="header navbar navbar-transparent navbar-fixed-top navbar-small">
            <!-- begin container -->
            <div class="container">
                <!-- begin navbar-header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#header-navbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="4936.html#" class="navbar-brand">
                        <span class="brand-logo"></span>
                        <span class="brand-text">
                            <span class="text-theme"><?=mb_substr($user['title'],0,5,'utf-8')?></span>
                        </span>
                    </a>
                </div>
                <!-- end navbar-header -->
                <!-- begin navbar-collapse -->
                <div class="collapse navbar-collapse" id="header-navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="#home" data-click="scroll-to-target">首页</a> </li>
                      	<li class=""><a href="#service" data-click="scroll-to-target">优势</a></li>
                        <li><a href="<?=$user2[0]['url']?>"><?=mb_substr($user2[0]['title'],0,2,'utf-8')?></a></li>
                        <li><a href="<?=$user2[1]['url']?>"><?=mb_substr($user2[1]['title'],0,2,'utf-8')?></a></li>
                        <li><a href="<?=$user2[2]['url']?>"><?=mb_substr($user2[2]['title'],0,2,'utf-8')?></a></li>
                        <li><a href="<?=$user2[3]['url']?>"><?=mb_substr($user2[3]['title'],0,2,'utf-8')?></a></li>
                    </ul>
                </div>
                <!-- end navbar-collapse -->
            </div>
            <!-- end container -->
        </div>
        <!-- end #header -->
        
        <!-- begin #home -->
        <div id="home" class="content has-bg home" style="height: 744px;">
            <!-- begin content-bg -->
<div class="content-bg"><img src="<?=$img[0]?>" alt="<?=$user['title']?>"></div>
            <!-- end content-bg -->
            <!-- begin container -->
            <div class="container home-content">
                <h1><?=$chengyu[0]?> <a href="<?=$xiadanurl?>"><?=mb_substr($user['title'],0,12,'utf-8')?></a></h1>
              <h3><?=mb_substr($user['keywords'],0,20,'utf-8')?></h3>
<h4><?=$user['description']?><br><a href="JavaScript:;"><sub><?=$user2[0]['keywords']?></sub></M></a></h4>
<a href="<?=$xiadanurl?>" class="btn btn-theme" style="background:#9BCD9B"><?=$button[0]?></a>
<a href="<?=$xiadanurl?>" class="btn btn-outline" style="background:#000080"><?=$button[1]?></a><br>
            </div>
            <!-- end container -->
        </div>
        <!-- end #home -->
    	
      	<!-- beign #service -->
        <div id="service" class="content" data-scrollview="true">
<div class="block-options pull-left"><i class="fa fa-book"></i>文章ID:<b><?=$user['id']?></b></div>
            <div class="block-options pull-right"><i class="fa fa-eye"></i>浏览量:<b><?=$user['count']?></b></div>
            <!-- begin container -->
            <div class="container">
                <h2 class="content-title">为什么选择我们？</h2>
                <p class="content-desc"><?=$user2[0]['description']?></p>
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-cog"></i></div>
                            <div class="info">
                                <h4 class="title"><?=$chengyu[0]?></h4>
                                <p class="desc"><?=$juzi[0]?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-paint-brush"></i></div>
                            <div class="info">
                                <h4 class="title"><?=$chengyu[1]?></h4>
                                <p class="desc"><?=$juzi[1]?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-file"></i></div>
                            <div class="info">
                                <h4 class="title"><?=$chengyu[2]?></h4>
                                <p class="desc"><?=$juzi[2]?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-code"></i></div>
                            <div class="info">
                                <h4 class="title"><?=mb_substr($user2[1]['title'],0,12,'utf-8')?></h4>
                                <p class="desc"><?=$user2[1]['description']?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-shopping-cart"></i></div>
                            <div class="info">
                                <h4 class="title"><?=mb_substr($user2[2]['title'],0,12,'utf-8')?></h4>
                                <p class="desc"><?=$user2[2]['description']?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-heart"></i></div>
                            <div class="info">
                                <h4 class="title"><?=mb_substr($user2[3]['title'],0,12,'utf-8')?></h4>
                                <p class="desc"><strong><?=$user2[3]['description']?></strong></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div> 
        
        
        <!-- 售后客服 -->      
 <div class="container">
                <h2 class="content-title">24小时售后客服</h2>
                <p class="content-desc"><center><?=$user2[1]['keywords'].$user2[2]['keywords']?></center></p>
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4 col-md-offset-4 col-sm-offset-4">
                        <!-- begin team -->
                        <div class="team">             
<div class="image flipInX contentAnimated finishAnimated" data-animation="true" data-animation-type="flipInX">
<img src="<?=$tximg[0]?>" alt="Mia Donovan"></div>

                        <div class="info">
                                <h3 class="name"><?=$chengyu[3]?></h3>
                                <div class="title text-theme"><?=$juzi[3]?></div>
<p><i class="fa fa-buysellads"></i>格式：<font color="#696969"><?=$classlist['list'][$type]?></font></p>
                                <div class="social">
                                    <a href="<?=$xiadanurl?>" target="_blank"><i class="fa fa-qq fa-lg fa-fw"></i></a>
                                    <a href="JavaScript:;"><i class="fa fa-weibo fa-lg fa-fw"></i></a>
                                    <a href="#"><i class="fa fa-home fa-lg fa-fw"></i></a>
                                </div>
                            </div>        </div>  
                        </div>

                        <!-- end team -->
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
            </div>  
    <!-- 售后客服 --> 

        <!-- begin #footer -->
        <div id="footer" class="footer">
            <div class="container">
                <div class="footer-brand">
<div class="footer-brand-logo"></div><?=mb_substr($user['title'],0,10,'utf-8')?></div>
<p><small class="block">Copyright © 2017-<?=date('Y')?> <?=mb_substr($user2[4]['description'],0,20,'utf-8')?></small></p>
<p><a class="block" href="<?=$user2[5]['url']?>" target="_blank"><?=$user2[5]['description']?></small></p>
        <p> <? foreach($user2 as $row){ echo'<a href="'.$row['url'].'">'.mb_substr($row['title'],0,10,'utf-8').'</a> | ';}?></p>
        
<? if($config['class_youlian']==1){ $yl_footer='<p name="'.$_SERVER['HTTP_HOST'].'"><center>友情链接：'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<a href="'.$yl_url.'" target="_blank">'.mb_substr($yl_name,0,6,'utf-8').'</a> | '; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</center></p>'; } ?>
<?=$config['article_footer']?>
            </div>
        </div>
<!-- end #footer -->
 
        
        <!-- begin theme-panel -->
        <div class="theme-panel">
            <div class="theme-panel-content">
                <ul class="theme-list clearfix">
                    <li><a href="javascript:;" class="bg-purple" data-theme="purple" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Purple" data-original-title="" title="">&nbsp;</a></li>
                    <li class="active"><a href="javascript:;" class="bg-blue" data-theme="blue" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Blue" data-original-title="" title="">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-green" data-theme="default" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Default" data-original-title="" title="">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-orange" data-theme="orange" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Orange" data-original-title="" title="">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-red" data-theme="red" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Red" data-original-title="" title="">&nbsp;</a></li>
                </ul>
            </div>
        </div>
        <!-- end theme-panel -->
    </div>
    <!-- end #page-container -->

	<!-- ================== BEGIN BASE JS ================== -->
	<script src="<?=$siteurl.$yx_mulu?>template/16/assets/js/jquery-1.9.1.min.js"></script>
	<script src="<?=$siteurl.$yx_mulu?>template/16/assets/js/jquery-migrate-1.1.0.min.js"></script>
	<script src="<?=$siteurl.$yx_mulu?>template/16/assets/js/bootstrap.min.js"></script>
	<!--[if lt IE 9]>
		<script src="assets/js/html5shiv.js"></script>
		<script src="assets/js/respond.min.js"></script>
		<script src="assets/js/excanvas.min.js"></script>
	<![endif]-->
	<script src="<?=$siteurl.$yx_mulu?>template/16/assets/js/jquery.cookie.js"></script>
	<script src="<?=$siteurl.$yx_mulu?>template/16/assets/js/scrollmonitor.js"></script>
	<script src="<?=$siteurl.$yx_mulu?>template/16/assets/js/apps.min.js"></script>
	<!-- ================== END BASE JS ================== -->
	
<script>$(document).ready(function() { App.init();});</script>
</body>
</html>