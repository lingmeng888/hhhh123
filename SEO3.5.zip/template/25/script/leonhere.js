function unableScroll() {
	var top = $(document).scrollTop();
	$(document).on('scroll.unable',function (e) {
		$(document).scrollTop(top);
	});
}
function enableScroll() {
	$(document).unbind('scroll.unable');
}
$(document).ready(function(){
	$('.nav li').each(function(){
		var _href = $(this).children('a').attr('href');
		if(_href == _url){
			$(this).addClass('cur');
		}
		if($(this).children('ul').length > 0){
			$(this).append('<em></em>');
		}
	});
	$('.submenu li').each(function(){
		var _h = $(this).children('a').attr('href');
		if(_h == _url){
			$(this).addClass('cur');
		}
	});
	$('.nav li em').click(function(){
		$(this).toggleClass('open').siblings('ul').stop().slideToggle('fast').parent().siblings('li').children('em').removeClass('open').siblings('ul').slideUp('fast');
	});

	$('.navbtn').click(function(){
		$('body').toggleClass('bodyOpen');
		$('.searchbox').hide();	
		if($('.nav').hasClass('open')){
			$('.nav').removeClass('open');
			enableScroll();
		}else{
			$('.nav').addClass('open');
			unableScroll();
		}		
	});	

	$('.schbtn').click(function(){
		enableScroll();
		$('body').removeClass('bodyOpen');
		$('.nav').removeClass('open');
		$('.searchbox').fadeToggle('fast');
	});
	$('#vcode').click(function(){
		$(this).attr('src',bloghost+'zb_system/script/c_validcode.php?id=zbmarketing&r='+Math.random());
	});
	var _null = 0;
	$('.message .submit').click(function(){
		$('.message span').remove();
		$('.message .text').each(function(){
			var _val = $(this).val();
			if(_val == ''){
				_null = 0;
				$(this).parent().after('<span>不能为空</span>');
			}else{
				_null = 1;
				$(this).parents('.item').find('span').remove();
			}
		});
		if(_null == 0){
			return false;
		}
	});
	

	$('.knowledge .tab li').click(function(){
		$(this).addClass('cur').siblings('li').removeClass('cur');
		var $_index = $(this).index();		
		$('.knowledge .box').eq($_index).addClass('cur').siblings().removeClass('cur');
	});
	
	$('.map .btn').click(function(){
		$(this).parents('.map').toggleClass('open');
	});

	$('.sidewidget .bt').click(function(){
		$('html,body').animate({scrollTop:0},500);
	});

	$('.sidewidget li').mouseover(function(){
		var _this = $(this).children('.sub');
		if(_this.length > 0) {
			_this.stop().fadeIn('fast');
		}
	}).mouseleave(function(){
		$(this).children('.sub').hide();
	});
	
	
	if($('#aboutpic').length > 0){		
		$('#aboutpic').owlCarousel({
			items:1,
			loop:true, 
			mouseDrag:true,
			autoplay:false,
			nav:true,	
			dots:false
		}); 
	}
	var slides = $('#slides');
	if(slides.length > 0){
		slides.on('initialized.owl.carousel', function(e) {
			$(this).siblings('.loading').remove();
		});		
		slides.owlCarousel({
			items:1,
			loop:true, 
			mouseDrag:true,
			autoplay:false,
			nav:true,	
			dots:false
		}); 
	}
	$(window).resize(function(){
		$('.why .clear').remove();
		if($('body').width() > 768){
			$('.why li:nth-child(4n)').after('<div class="clear"></div>');
		}else{
			$('.why li:nth-child(2n)').after('<div class="clear"></div>');
		}
		if($('body').width() > 980){
			enableScroll();
			$('.nav li').on('mouseover mouseleave');
			$('.nav li').mouseover(function(){
				$(this).addClass('on').children('ul').stop().slideDown('fast');
			}).mouseleave(function(){
				$(this).removeClass('on').children('ul').hide();
			});
		}else{
			$('.nav li').off('mouseover mouseleave');
		}
	}).trigger('resize');

	/**/
	$('.searchbox .submit').click(function(){
		if($(this).siblings('.text').val() == ''){
			alert('请输入关键词搜索！');
			return false;
		}
	});	
	$('.divSearchPanel input[type="submit"]').click(function(){
		if($(this).siblings('input').val() == ''){
			alert('请输入关键词搜索！');
			return false;
		}
	});	
});