<? if (strpos($_SERVER['PHP_SELF'],'template')!== false&&strpos($_SERVER['PHP_SELF'],'index.php')!== false){
  header("HTTP/1.1 404 Not Found");
  header("Status: 404 Not Found");  exit;} ?>

<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="utf-8">
	<title><?=$user['title']?></title>
  	<meta name="keywords" content="<?=$user['keywords']?>">
	<meta name="description" content="<?=$user['description']?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">
    <meta name="applicable-device" content="pc,mobile">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/13/css/prism.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/13/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/13/css/all.min.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/13/css/chocolat.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/13/css/style.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/13/css/custom.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/13/css/style_1.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/13/css/swiper.min.css">

    <style>
        .pricing {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.03);
            background-color: #fff;
            border-radius: 3px;
            border: none;
            position: relative;
            margin-bottom: 30px;
            text-align: center;
        }

        .pricing.pricing-highlight .pricing-title {
            background-color: #6777ef;
            color: #fff;
        }

        .pricing.pricing-highlight .pricing-cta a {
            background-color: #6777ef;
            color: #fff;
        }

        .pricing.pricing-highlight .pricing-cta a:hover {
            background-color: #394eea !important;
        }

        .pricing .pricing-padding {
            padding: 40px;
        }

        .pricing .pricing-title {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2.5px;
            background-color: #f3f6f8;
            color: #6777ef;
            border-radius: 0 0 3px 3px;
            display: inline-block;
            padding: 5px 15px;
        }

        .pricing .pricing-price {
            margin-bottom: 45px;
            color: #6c757d
        }

        .pricing .pricing-price div:first-child {
            font-weight: 600;
            font-size: 50px;
        }

        .pricing .pricing-details {
            text-align: left;
            display: inline-block;
            color: #6c757d;
        }

        .pricing .pricing-details .pricing-item {
            display: flex;
            margin-bottom: 15px;
        }

        .pricing .pricing-details .pricing-item .pricing-item-icon {
            width: 20px;
            height: 20px;
            line-height: 20px;
            border-radius: 50%;
            text-align: center;
            background-color: #63ed7a;
            color: #fff;
            margin-right: 10px;
        }

        .pricing .pricing-details .pricing-item .pricing-item-icon i {
            font-size: 11px;
        }

        .pricing .pricing-cta {
            margin-top: 20px;
        }

        .pricing .pricing-cta a {
            display: block;
            padding: 20px 40px;
            background-color: #f3f6f8;
            text-transform: uppercase;
            letter-spacing: 2.5px;
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            border-radius: 0 0 3px 3px;
        }

        .pricing .pricing-cta a .fas,
        .pricing .pricing-cta a .far,
        .pricing .pricing-cta a .fab,
        .pricing .pricing-cta a .fal,
        .pricing .pricing-cta a .ion {
            margin-left: 5px;
        }

        .pricing .pricing-cta a:hover {
            background-color: #e3eaef;
        }
    </style>
</head>


<body class="">
    <nav class="navbar navbar-reverse navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand smooth" href="#"><?=mb_substr($user['title'],0,5,'utf-8')?></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto ml-lg-3 align-items-lg-center">
                    <li class="nav-item"><a href="#features" class="nav-link">特性</a></li>
                    <li class="nav-item"><a href="#contact-support" class="nav-link">支持</a></li>
                    <li class="nav-item d-lg-none d-md-block"><a href="<?=$xiadanurl?>" target="_blank"  class="nav-link smooth"><?=$button[0]?></a></li>
                    <li class="nav-item"><a class="nav-link" href="https://www.baidu.com/s?wd=site:<?=$_SERVER['HTTP_HOST']?>" target="_blank"  style="cursor:pointer">百度<?=mb_substr($user['title'],0,2,'utf-8')?></a></li>
                </ul>
                <ul class="navbar-nav ml-auto align-items-lg-center d-none d-lg-block">
                    <li class="ml-lg-3 nav-item">
                        <a href="<?=$xiadanurl?>" class="btn btn-round smooth btn-icon icon-left">
                            <i class="fas fa-sign-in-alt"></i> <?=$button[1]?>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero-wrapper" id="top">
        <div class="hero">
            <div class="container">
                <div class="text text-center text-lg-left">
                    <a class="headline">
                        <div class="badge badge-danger">New</div>
                        <?=mb_substr($user['keywords'],0,30,'utf-8')?><i class="fas fa-chevron-right"></i>
                    </a>
                    <h1><?=mb_substr($user['title'],0,6,'utf-8')?></h1>
                    <p class="lead">
                    <?=mb_substr($user['description'],0,80,'utf-8')?>
                    </p>
                    <div class="cta">
                        <a class="btn btn-lg btn-warning btn-icon icon-right" href="<?=$xiadanurl?>"><?=$button[0]?> <i class="fas fa-chevron-right"></i></a> &nbsp;
                    </div>
                    <div class="mt-3 text-job d-lg-none">
                        <a style="color:rgba(255,255,255,.6);">
                            期待您的加入
                        </a>
                    </div>
                </div>
                <div class="image d-none d-lg-block">
                    <img src="<?=$siteurl.$yx_mulu?>template/13/img/cloud.png" alt="<?=$user['title']?>">
                </div>
            </div>
        </div>
    </div>
    <div class="callout container">
        <div class="row">
            <div class="col-md-6 col-12 mb-4 mb-lg-0">
                <div class="text-job text-muted text-14">为什么选择 <?=$user['title']?></div>
                <div class="h1 mb-0 font-weight-bold mt-1" style="font-size: 2rem;">迄今为止
                </div>
            </div>
            <div class="col-4 col-md-2 text-center">
                <div class="h2 font-weight-bold"><?=$user['id']?>+</div>
                <div class="text-uppercase font-weight-bold ls-2 text-primary">我们的客户</div>
            </div>
            <div class="col-4 col-md-2 text-center">
                <div class="h2 font-weight-bold" id="days">999+</div>
                <div class="text-uppercase font-weight-bold ls-2 text-primary">已运营天数</div>
            </div>
        </div>
    </div>

    <section id="features">
        <div class="container">
            <div class="row mb-5 text-center">
                <div class="col-lg-10 offset-lg-1">
                    <h2>为你 <span class="text-primary">量身定制</span> 的服务</h2>
                    <p class="lead"><?=mb_substr($user['title'],0,6,'utf-8')?>-致力于为用户提供最稳定的服务</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="features">
                        <div class="feature">
                            <div class="feature-icon">
                                <i class="fas fa-mobile-alt"></i>
                            </div>
                            <h5><?=mb_substr($user2[0]['title'],0,15,'utf-8')?></h5>
                            <p><?=$user2[0]['description']?></p>
                        </div>
                        <div class="feature">
                            <div class="feature-icon">
                                <i class="fab fa-html5"></i>
                            </div>
                          <h5><?=mb_substr($user2[1]['title'],0,15,'utf-8')?></h5>
                            <p><?=$user2[1]['description']?></p>
                        </div>
                        <div class="feature">
                            <div class="feature-icon">
                                <i class="fas fa-fire"></i>
                            </div>
                            <h5><?=mb_substr($user2[2]['title'],0,15,'utf-8')?></h5>
                            <p><?=$user2[2]['description']?></p>
                        </div>
                        <div class="feature">
                            <div class="feature-icon">
                                <i class="fas fa-check"></i>
                            </div>
                          <h5><?=mb_substr($user2[3]['title'],0,15,'utf-8')?></h5>
                            <p><?=$user2[3]['description']?></p>
                        </div>
                        <div class="feature">
                            <div class="feature-icon">
                                <i class="fas fa-upload"></i>
                            </div>
                      <h5><?=mb_substr($user2[4]['title'],0,15,'utf-8')?></h5>
                            <p><?=$user2[4]['description']?></p>
                        </div>
                        <div class="feature">
                            <div class="feature-icon">
                                <i class="fas fa-columns"></i>
                            </div>
                          <h5><?=mb_substr($user2[5]['title'],0,15,'utf-8')?></h5>
                            <p><?=$user2[5]['description']?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section id="support-us" class="support-us section-design">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 d-none d-lg-block">
                    <img src="<?=$img[0]?>" alt="user flow" class="img-fluid" style="width:30rem">
                </div>
                <div class="col-lg-4 col-md-12">
                    <h2><?=$user['title']?></h2>
                    <p class="lead">* 老牌平台，值得信赖</p>
                    <ul class="list-icons">
                        <li>
                            <span class="card-icon bg-primary text-white">
                                <i class="fas fa-ad"></i>
                            </span>
                            <span><?=$user2[0]['keywords']?></span>
                        </li>
                        <li>
                            <span class="card-icon bg-primary text-white">
                                <i class="fas fa-filter"></i>
                            </span>
                            <span><?=$user2[1]['keywords']?></span>
                        </li>
                        <li>
                            <span class="card-icon bg-primary text-white">
                                <i class="fas fa-tachometer-alt"></i>
                            </span>
                            <span><?=$user2[2]['keywords']?></span>
                        </li>
                        <li>
                            <span class="card-icon bg-primary text-white">
                                <i class="fab fa-qq"></i>
                            </span>
                            <span><?=$user2[3]['keywords']?></span>
                        </li>
                        <li>
                            <span class="card-icon bg-primary text-white">
                                <i class="fas fa-lock"></i>
                            </span>
                            <span><?=$user2[4]['keywords']?></span>
                        </li>
                        <li>
                            <span class="card-icon bg-primary text-white">
                                <i class="fas fa-mobile-alt"></i>
                            </span>
                            <span><?=$user2[5]['keywords']?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>


    <section id="try" class="section-dark">
        <div class="container ">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="col-lg-8 offset-lg-2 text-center">
                            <blockquote>所有用户信息我们均采用加密协议传输，让用户隐私得到保障，用得放心。</blockquote>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="download-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <h2>开始使用优秀的<?=mb_substr($user['title'],0,5,'utf-8')?></h2>
                    <p class="lead"><?=$_SERVER['HTTP_HOST']?></p>
                </div>
                <div class="col-md-5 text-right">
                    <a href="" class="btn btn-primary btn-lg"><?=$button[0]?></a>
                </div>
            </div>
        </div>
    </section>

    <section id="contact-support" class="before-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="card long-shadow">
                        <div class="card-body p-45 d-flex">
                            <div class="card-icon bg-primary text-white">
                                <i class="far fa-life-ring"></i>
                            </div>
                            <div>
                                <h5><?=$chengyu[0]?></h5>
                                <p><?=$user['title']?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <h3 class="text-capitalize"><?=mb_substr($user['title'],0,5,'utf-8')?></h3>
                    <div class="pr-lg-5">
                        <p>致力于为用户提供最稳定的服务</p>
                    </div>
                </div>
                <div class="col-md-7">
                    <ul>
                        <li>
                            <hr>
<? foreach($user2 as $row){?>                           
<font size="1"><a href="<?=$row['url']?>"><?=mb_substr($row['title'],0,10,'utf-8')?></a></font> |
<?}?> 
                        </li>
                    </ul>
                </div>
            </div>  
    
        
        
<? if($config['class_youlian']==1){ $yl_footer='<p name="'.$_SERVER['HTTP_HOST'].'"><center>友情链接：'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<a href="'.$yl_url.'" target="_blank">'.mb_substr($yl_name,0,5,'utf-8').'</a> | '; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</center></p>'; } ?>
<?=$config['article_footer']?>
</div> 
    </footer>

</body>
</html>