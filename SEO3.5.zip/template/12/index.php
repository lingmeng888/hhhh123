<? if (strpos($_SERVER['PHP_SELF'],'template')!== false&&strpos($_SERVER['PHP_SELF'],'index.php')!== false){
  header("HTTP/1.1 404 Not Found");
  header("Status: 404 Not Found");  exit;}?>

<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?=$user['title']?></title>
  	<meta name="keywords" content="<?=$user['keywords']?>">
	<meta name="description" content="<?=$user['description']?>">
    <link href="<?=$siteurl.$yx_mulu?>template/11/font_1982723_3ves5qdacbf.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/11/style-starter.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/11/rocket.css">
</head>
<body>
<header id="site-header" class="fixed-top">
    <div class="container">
        <nav class="navbar navbar-expand-lg stroke px-0">
            <h1> <a class="navbar-brand" href="/">
                <span class="iconfont iconhuojian1"></span> <?=mb_substr($user['title'],0,4,'utf-8')?></a></h1>
            <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                <span class="navbar-toggler-icon fa icon-close fa-times"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">首页 <span class="sr-only">(current)</span></a>
                    </li>
                   <li class="nav-item @@about__active"><a class="nav-link" href="#" style="cursor:pointer" ;=""></a></li>                </ul>
            </div>
            <!-- toggle switch for light and dark theme -->
            <div class="mobile-position" style="margin-left: 5px;">
                <nav class="navigation">
                    <div class="theme-switch-wrapper">
                        <label class="theme-switch" for="checkbox">
                            <input type="checkbox" id="checkbox">
                            <div class="mode-container">
                                <i class="gg-sun"></i>
                                <i class="gg-moon"></i>
                            </div>
                        </label>
                    </div>
                </nav>
            </div>
            <!-- //toggle switch for light and dark theme -->
        </nav>
    </div>
</header>
<!--/header-->
<!-- main-slider -->
<section class="w3l-main-slider" id="home">
    <div class="companies20-content">
        <div class="owl-one owl-carousel owl-theme owl-loaded owl-drag">
            
        <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-2526px, 0px, 0px); transition: all 0s ease 0s; width: 6315px;"><div class="owl-item cloned" style="width: 1263px;"><div class="item">
                <li>
                    <div class="slider-info banner-view bg bg2">
                        <div class="banner-info">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6 banner-info-bg">
                                        <h5><?=mb_substr($user['title'],0,9,'utf-8')?></h5>
                                        <p class="mt-md-4 mt-3"><?=$user['description']?></p>
                                        </div>
                                    <div class="col-lg-5 offset-lg-1">
                                        <div class="video-link">
                                            <div class="rocket">
                                                <div class="rocket-ship--ship">
                                                    <div class="rocket-ship--fuselage">
                                                        <svg x="0px" y="0px" viewBox="0 0 279 302.9">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M59.9,218.5l1.9,19.1c0.9,6.9,2.1,13.6,3.4,19.9l3.8,15L34.1,282
                                                          l-0.7-6.4c-1.3-10.4-2.7-19.8-4.4-28.4l-0.6-2.6L59.9,218.5L59.9,218.5z M218.1,218.5l32.5,26.9l-1.6,6.8c-1.7,8.6-3.2,18-4.4,28.4
                                                          l-0.2,1.6l-35.4-9.6l3.8-15c1.3-6.4,2.5-13,3.4-19.9L218.1,218.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M66.4,112.5h145.1l1,4.4c4.4,21.9,6.6,46.9,6.6,75.7
                                                          c0,32.3-4,60-10.8,83.1l-2.3,7.1h-67H72l-2.3-7.1c-6.9-23.1-10.8-50.8-10.8-83.1c0-28.9,2.1-53.9,6.6-75.7L66.4,112.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,4.7l9.2,6.4c24.5,18.2,42.2,40.5,53.9,69.8l5.4,16.6H70.6
                                                          L76,80.9c11.6-29.3,29.4-51.6,53.9-69.8L139,4.7z"></path>
                                                            <polygon fill-rule="evenodd" clip-rule="evenodd" fill="rgba(242, 242, 242,0.5)" points="70.4,97.5 207.6,97.5 209.6,104.2 211.5,112.5
                                                          66.5,112.5 68.4,104.2 70.4,97.5 	"></polygon>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#f2f2f2" d="M91,145.4c0-26.5,21.5-47.9,48-47.9s48,21.5,48,47.9
                                                          s-21.5,47.9-48,47.9S91,171.9,91,145.4L91,145.4z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M106.1,145.3c0-18.2,14.7-32.9,32.9-32.9s32.9,14.7,32.9,32.9
                                                          c0,18.2-14.7,32.9-32.9,32.9S106.1,163.5,106.1,145.3L106.1,145.3z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M18.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6H1
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L18.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M259.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6
                                                          h-34.9l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L259.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,210.1l2.3,6.4c6.2,18.2,10.7,40.5,13.7,69.8l1.4,16.6h-34.8
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.7-69.8L139,210.1z"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="rocket-ship--contrail">
                                                        <div class="rocket-ship--tail">
                                                            <div class="rocket-ship--flame"></div>
                                                        </div>
                                                        <div class="rocket-ship--cloud">
                                                            <div class="rocket-ship--smoke -one"></div>
                                                            <div class="rocket-ship--smoke -two"></div>
                                                            <div class="rocket-ship--smoke -three"></div>
                                                            <div class="rocket-ship--smoke -four"></div>
                                                            <div class="rocket-ship--smoke -five"></div>
                                                            <div class="rocket-ship--smoke -six"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </div></div><div class="owl-item cloned" style="width: 1263px;"><div class="item">
                <li>
                    <div class="slider-info banner-view bg bg2">
                        <div class="banner-info">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6 banner-info-bg">
                                        <h5><?=mb_substr($user['title'],0,9,'utf-8')?></h5>
                                        <p class="mt-md-4 mt-3"><?=$user['keywords']?></p>
                                        </div>
                                    <div class="col-lg-5 offset-lg-1">
                                        <div class="video-link">
                                            <div class="rocket">
                                                <div class="rocket-ship--ship">
                                                    <div class="rocket-ship--fuselage">
                                                        <svg x="0px" y="0px" viewBox="0 0 279 302.9">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M59.9,218.5l1.9,19.1c0.9,6.9,2.1,13.6,3.4,19.9l3.8,15L34.1,282
                                                          l-0.7-6.4c-1.3-10.4-2.7-19.8-4.4-28.4l-0.6-2.6L59.9,218.5L59.9,218.5z M218.1,218.5l32.5,26.9l-1.6,6.8c-1.7,8.6-3.2,18-4.4,28.4
                                                          l-0.2,1.6l-35.4-9.6l3.8-15c1.3-6.4,2.5-13,3.4-19.9L218.1,218.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M66.4,112.5h145.1l1,4.4c4.4,21.9,6.6,46.9,6.6,75.7
                                                          c0,32.3-4,60-10.8,83.1l-2.3,7.1h-67H72l-2.3-7.1c-6.9-23.1-10.8-50.8-10.8-83.1c0-28.9,2.1-53.9,6.6-75.7L66.4,112.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,4.7l9.2,6.4c24.5,18.2,42.2,40.5,53.9,69.8l5.4,16.6H70.6
                                                          L76,80.9c11.6-29.3,29.4-51.6,53.9-69.8L139,4.7z"></path>
                                                            <polygon fill-rule="evenodd" clip-rule="evenodd" fill="rgba(242, 242, 242,0.5)" points="70.4,97.5 207.6,97.5 209.6,104.2 211.5,112.5
                                                          66.5,112.5 68.4,104.2 70.4,97.5 	"></polygon>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#f2f2f2" d="M91,145.4c0-26.5,21.5-47.9,48-47.9s48,21.5,48,47.9
                                                          s-21.5,47.9-48,47.9S91,171.9,91,145.4L91,145.4z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M106.1,145.3c0-18.2,14.7-32.9,32.9-32.9s32.9,14.7,32.9,32.9
                                                          c0,18.2-14.7,32.9-32.9,32.9S106.1,163.5,106.1,145.3L106.1,145.3z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M18.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6H1
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L18.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M259.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6
                                                          h-34.9l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L259.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,210.1l2.3,6.4c6.2,18.2,10.7,40.5,13.7,69.8l1.4,16.6h-34.8
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.7-69.8L139,210.1z"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="rocket-ship--contrail">
                                                        <div class="rocket-ship--tail">
                                                            <div class="rocket-ship--flame"></div>
                                                        </div>
                                                        <div class="rocket-ship--cloud">
                                                            <div class="rocket-ship--smoke -one"></div>
                                                            <div class="rocket-ship--smoke -two"></div>
                                                            <div class="rocket-ship--smoke -three"></div>
                                                            <div class="rocket-ship--smoke -four"></div>
                                                            <div class="rocket-ship--smoke -five"></div>
                                                            <div class="rocket-ship--smoke -six"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </div></div><div class="owl-item active" style="width: 1263px;"><div class="item">
                <li>
                    <div class="slider-info banner-view bg bg2">
                        <div class="banner-info">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6 banner-info-bg">
                                        <h5><?=mb_substr($user['title'],0,9,'utf-8')?></h5>
                                        <p class="mt-md-4 mt-3"><?=$user['keywords']?></p>
                          <a class="btn btn-style btn-danger mt-sm-5 mt-4 mr-2" href="<?=$xiadanurl?>"><?=$button[0]?></a>
                                        </div>
                                    <div class="col-lg-5 offset-lg-1">
                                        <div class="video-link">
                                            <div class="rocket">
                                                <div class="rocket-ship--ship">
                                                    <div class="rocket-ship--fuselage">
                                                        <svg x="0px" y="0px" viewBox="0 0 279 302.9">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M59.9,218.5l1.9,19.1c0.9,6.9,2.1,13.6,3.4,19.9l3.8,15L34.1,282
                                                          l-0.7-6.4c-1.3-10.4-2.7-19.8-4.4-28.4l-0.6-2.6L59.9,218.5L59.9,218.5z M218.1,218.5l32.5,26.9l-1.6,6.8c-1.7,8.6-3.2,18-4.4,28.4
                                                          l-0.2,1.6l-35.4-9.6l3.8-15c1.3-6.4,2.5-13,3.4-19.9L218.1,218.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M66.4,112.5h145.1l1,4.4c4.4,21.9,6.6,46.9,6.6,75.7
                                                          c0,32.3-4,60-10.8,83.1l-2.3,7.1h-67H72l-2.3-7.1c-6.9-23.1-10.8-50.8-10.8-83.1c0-28.9,2.1-53.9,6.6-75.7L66.4,112.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,4.7l9.2,6.4c24.5,18.2,42.2,40.5,53.9,69.8l5.4,16.6H70.6
                                                          L76,80.9c11.6-29.3,29.4-51.6,53.9-69.8L139,4.7z"></path>
                                                            <polygon fill-rule="evenodd" clip-rule="evenodd" fill="rgba(242, 242, 242,0.5)" points="70.4,97.5 207.6,97.5 209.6,104.2 211.5,112.5
                                                          66.5,112.5 68.4,104.2 70.4,97.5 	"></polygon>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#f2f2f2" d="M91,145.4c0-26.5,21.5-47.9,48-47.9s48,21.5,48,47.9
                                                          s-21.5,47.9-48,47.9S91,171.9,91,145.4L91,145.4z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M106.1,145.3c0-18.2,14.7-32.9,32.9-32.9s32.9,14.7,32.9,32.9
                                                          c0,18.2-14.7,32.9-32.9,32.9S106.1,163.5,106.1,145.3L106.1,145.3z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M18.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6H1
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L18.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M259.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6
                                                          h-34.9l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L259.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,210.1l2.3,6.4c6.2,18.2,10.7,40.5,13.7,69.8l1.4,16.6h-34.8
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.7-69.8L139,210.1z"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="rocket-ship--contrail">
                                                        <div class="rocket-ship--tail">
                                                            <div class="rocket-ship--flame"></div>
                                                        </div>
                                                        <div class="rocket-ship--cloud">
                                                            <div class="rocket-ship--smoke -one"></div>
                                                            <div class="rocket-ship--smoke -two"></div>
                                                            <div class="rocket-ship--smoke -three"></div>
                                                            <div class="rocket-ship--smoke -four"></div>
                                                            <div class="rocket-ship--smoke -five"></div>
                                                            <div class="rocket-ship--smoke -six"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </div></div><div class="owl-item cloned" style="width: 1263px;"><div class="item">
                <li>
                    <div class="slider-info banner-view bg bg2">
                        <div class="banner-info">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6 banner-info-bg">
                                        <h5><?=mb_substr($user['title'],0,9,'utf-8')?></h5>
                                        <p class="mt-md-4 mt-3"><?=$user['description']?></p>
                             <a class="btn btn-style btn-danger mt-sm-5 mt-4 mr-2" href="<?=$xiadanurl?>"><?=$button[1]?></a>
                                        </div>
                                    <div class="col-lg-5 offset-lg-1">
                                        <div class="video-link">
                                            <div class="rocket">
                                                <div class="rocket-ship--ship">
                                                    <div class="rocket-ship--fuselage">
                                                        <svg x="0px" y="0px" viewBox="0 0 279 302.9">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M59.9,218.5l1.9,19.1c0.9,6.9,2.1,13.6,3.4,19.9l3.8,15L34.1,282
                                                          l-0.7-6.4c-1.3-10.4-2.7-19.8-4.4-28.4l-0.6-2.6L59.9,218.5L59.9,218.5z M218.1,218.5l32.5,26.9l-1.6,6.8c-1.7,8.6-3.2,18-4.4,28.4
                                                          l-0.2,1.6l-35.4-9.6l3.8-15c1.3-6.4,2.5-13,3.4-19.9L218.1,218.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M66.4,112.5h145.1l1,4.4c4.4,21.9,6.6,46.9,6.6,75.7
                                                          c0,32.3-4,60-10.8,83.1l-2.3,7.1h-67H72l-2.3-7.1c-6.9-23.1-10.8-50.8-10.8-83.1c0-28.9,2.1-53.9,6.6-75.7L66.4,112.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,4.7l9.2,6.4c24.5,18.2,42.2,40.5,53.9,69.8l5.4,16.6H70.6
                                                          L76,80.9c11.6-29.3,29.4-51.6,53.9-69.8L139,4.7z"></path>
                                                            <polygon fill-rule="evenodd" clip-rule="evenodd" fill="rgba(242, 242, 242,0.5)" points="70.4,97.5 207.6,97.5 209.6,104.2 211.5,112.5
                                                          66.5,112.5 68.4,104.2 70.4,97.5 	"></polygon>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#f2f2f2" d="M91,145.4c0-26.5,21.5-47.9,48-47.9s48,21.5,48,47.9
                                                          s-21.5,47.9-48,47.9S91,171.9,91,145.4L91,145.4z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M106.1,145.3c0-18.2,14.7-32.9,32.9-32.9s32.9,14.7,32.9,32.9
                                                          c0,18.2-14.7,32.9-32.9,32.9S106.1,163.5,106.1,145.3L106.1,145.3z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M18.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6H1
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L18.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M259.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6
                                                          h-34.9l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L259.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,210.1l2.3,6.4c6.2,18.2,10.7,40.5,13.7,69.8l1.4,16.6h-34.8
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.7-69.8L139,210.1z"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="rocket-ship--contrail">
                                                        <div class="rocket-ship--tail">
                                                            <div class="rocket-ship--flame"></div>
                                                        </div>
                                                        <div class="rocket-ship--cloud">
                                                            <div class="rocket-ship--smoke -one"></div>
                                                            <div class="rocket-ship--smoke -two"></div>
                                                            <div class="rocket-ship--smoke -three"></div>
                                                            <div class="rocket-ship--smoke -four"></div>
                                                            <div class="rocket-ship--smoke -five"></div>
                                                            <div class="rocket-ship--smoke -six"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </div></div><div class="owl-item cloned" style="width: 1263px;"><div class="item">
                <li>
                    <div class="slider-info banner-view bg bg2">
                        <div class="banner-info">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6 banner-info-bg">
                                        <h5><?=mb_substr($user['title'],0,5,'utf-8')?></h5>
                                        <p class="mt-md-4 mt-3"><?=$juzi[0]?></p>
                        
                                        </div>
                                    <div class="col-lg-5 offset-lg-1">
                                        <div class="video-link">
                                            <div class="rocket">
                                                <div class="rocket-ship--ship">
                                                    <div class="rocket-ship--fuselage">
                                                        <svg x="0px" y="0px" viewBox="0 0 279 302.9">
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M59.9,218.5l1.9,19.1c0.9,6.9,2.1,13.6,3.4,19.9l3.8,15L34.1,282
                                                          l-0.7-6.4c-1.3-10.4-2.7-19.8-4.4-28.4l-0.6-2.6L59.9,218.5L59.9,218.5z M218.1,218.5l32.5,26.9l-1.6,6.8c-1.7,8.6-3.2,18-4.4,28.4
                                                          l-0.2,1.6l-35.4-9.6l3.8-15c1.3-6.4,2.5-13,3.4-19.9L218.1,218.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M66.4,112.5h145.1l1,4.4c4.4,21.9,6.6,46.9,6.6,75.7
                                                          c0,32.3-4,60-10.8,83.1l-2.3,7.1h-67H72l-2.3-7.1c-6.9-23.1-10.8-50.8-10.8-83.1c0-28.9,2.1-53.9,6.6-75.7L66.4,112.5z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,4.7l9.2,6.4c24.5,18.2,42.2,40.5,53.9,69.8l5.4,16.6H70.6
                                                          L76,80.9c11.6-29.3,29.4-51.6,53.9-69.8L139,4.7z"></path>
                                                            <polygon fill-rule="evenodd" clip-rule="evenodd" fill="rgba(242, 242, 242,0.5)" points="70.4,97.5 207.6,97.5 209.6,104.2 211.5,112.5
                                                          66.5,112.5 68.4,104.2 70.4,97.5 	"></polygon>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#f2f2f2" d="M91,145.4c0-26.5,21.5-47.9,48-47.9s48,21.5,48,47.9
                                                          s-21.5,47.9-48,47.9S91,171.9,91,145.4L91,145.4z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M106.1,145.3c0-18.2,14.7-32.9,32.9-32.9s32.9,14.7,32.9,32.9
                                                          c0,18.2-14.7,32.9-32.9,32.9S106.1,163.5,106.1,145.3L106.1,145.3z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M18.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6H1
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L18.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M259.5,210.1l2.3,6.4c6.3,18.2,10.8,40.5,13.8,69.8l1.4,16.6
                                                          h-34.9l1.4-16.6c3-29.3,7.5-51.6,13.8-69.8L259.5,210.1z"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M139,210.1l2.3,6.4c6.2,18.2,10.7,40.5,13.7,69.8l1.4,16.6h-34.8
                                                          l1.4-16.6c3-29.3,7.5-51.6,13.7-69.8L139,210.1z"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="rocket-ship--contrail">
                                                        <div class="rocket-ship--tail">
                                                            <div class="rocket-ship--flame"></div>
                                                        </div>
                                                        <div class="rocket-ship--cloud">
                                                            <div class="rocket-ship--smoke -one"></div>
                                                            <div class="rocket-ship--smoke -two"></div>
                                                            <div class="rocket-ship--smoke -three"></div>
                                                            <div class="rocket-ship--smoke -four"></div>
                                                            <div class="rocket-ship--smoke -five"></div>
                                                            <div class="rocket-ship--smoke -six"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </div></div></div></div><div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous"> <span class="fa fa-angle-left"></span> </span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next"> <span class="fa fa-angle-right"></span> </span></button></div><div class="owl-dots disabled"><button role="button" class="owl-dot active"><span></span></button></div></div>
    </div>
</section>
<!-- /main-slider -->
<!-- home page block1 -->
<section id="about" class="home-services pt-lg-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="box-wrap">
                    <div class="box-wrap-grid">
                        <div class="icon">
                            <span class="iconfont iconHome"></span>
                        </div>
                        <div class="info">
                            <h4><a href="javascripe:;">平台服务</a></h4>
                            <p>稳定、安全、值得信赖</p>
                        </div>
                    </div>
                    <p class="mt-4"><?=$user2[0]['description']?></p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 mt-md-0 mt-4">
                <div class="box-wrap">
                    <div class="box-wrap-grid">
                        <div class="icon">
                            <span class="iconfont iconBookmark"></span>
                        </div>
                        <div class="info">
                            <h4><a href="javascripe:;">平台优势</a></h4>
                            <p>以质量求生存，以信誉促发展，已开单速度为己任</p>
                        </div>
                    </div>
                    <p class="mt-4"><?=$user2[1]['description']?></p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 mt-lg-0 mt-4">
                <div class="box-wrap">
                    <div class="box-wrap-grid">
                        <div class="icon">
                            <span class="iconfont iconDiscovery"></span>
                        </div>
                        <div class="info">
                            <h4><a href="javascripe:;">站长心得</a></h4>
                            <p>时间证明一切，我们始终相信有售后才有未来！</p>
                        </div>
                    </div>
                    <p class="mt-4"><?=$user2[2]['description']?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //home page block1 -->
<!-- about page about section -->
<section class="w3l-index3" id="about2">
    <div class="midd-w3 py-5">
        <div class="container py-lg-5 py-md-3">
            <div class="row">
                <div class="col-lg-7 mb-lg-0 mb-md-5 mb-4 align-self">
                    <h3 class="title-left mx-0">系统优势：</h3>
                    <p class="mt-md-4 mt-3"><?=$user2[0]['title']?></p>
                    <p class="mt-md-4 mt-3"><?=$user2[1]['title']?></p>
                    <p class="mt-md-4 mt-3"><?=$user2[2]['title']?></p>
                    <a class="btn btn-style btn-primary mt-sm-5 mt-4 mr-2" href="<?=$xiadanurl?>"> <?=$button[0]?></a>
                    <a class="btn btn-style btn-primary mt-sm-5 mt-4 mr-2" href="<?=$xiadanurl?>"> <?=$button[1]?></a>
                </div>
                <div class="col-lg-5">
                    <div class="position-relative">
                        <img src="<?=$img[0]?>" alt="" class="radius-image img-fluid" style="width: 70%;margin-left: 4rem;">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- //about page about section -->
<!-- /mobile section --->
<section class="w3l-mobile-content-6 py-5">
    <div class="mobile-info py-lg-5 py-md-4 py-2">
        <!-- /mobile-info-->
        <div class="container">
            <h3 class="title-big mb-5 text-center">我们所拥有的业务</h3>
            <div class="row mobile-info-inn mx-lg-0">
                <div class="col-lg-4 mobile-right text-right">
                    <div class="row mobile-right-grids mb-lg-5 mb-4">
                        <div class="col-10 mobile-right-info">
                            <h6><a href="<?=$user2[0]['url']?>"><?=mb_substr($user2[0]['title'],0,4,'utf-8')?></a></h6>
                            <p><?=mb_substr($user2[0]['description'],0,50,'utf-8')?></p>
                        </div>
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="iconfont iconshiftManagement"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row mobile-right-grids mb-lg-5 mb-4">
                        <div class="col-10 mobile-right-info">
                            <h6><a href="<?=$user2[1]['url']?>"><?=mb_substr($user2[1]['title'],0,4,'utf-8')?></a></h6>
                            <p><?=mb_substr($user2[1]['description'],0,50,'utf-8')?></p>
                        </div>
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="iconfont icondutyManagement"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row mobile-right-grids">
                        <div class="col-10 mobile-right-info">
                            <h6><a href="<?=$user2[2]['url']?>"><?=mb_substr($user2[2]['title'],0,4,'utf-8')?> </a></h6>
                            <p><?=mb_substr($user2[2]['description'],0,50,'utf-8')?></p>
                        </div>
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="iconfont iconlogbook"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mobile-left px-lg-5">
                    <img src="<?=$img[1]?>" class="img-fluid radius-image" alt="">
                </div>
                <div class="col-lg-4 mobile-right">
                    <div class="row mobile-right-grids mb-lg-5 mb-4">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="iconfont iconwasreleased"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                            <h6><a href="<?=$user2[3]['url']?>"><?=mb_substr($user2[3]['title'],0,4,'utf-8')?></a></h6>
                            <p><?=mb_substr($user2[3]['description'],0,50,'utf-8')?></p>
                        </div>
                    </div>
                    <div class="row mobile-right-grids mb-lg-5 mb-4">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="iconfont iconvalidationResults"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                            <h6><a href="<?=$user2[4]['url']?>"><?=mb_substr($user2[4]['title'],0,4,'utf-8')?></a></h6>
                            <p><?=mb_substr($user2[4]['description'],0,50,'utf-8')?></p>
                        </div>
                    </div>
                    <div class="row mobile-right-grids">
                        <div class="col-2 mobile-right-icon">
                            <div class="mobile-icon">
                                <span class="iconfont icondailyBriefing"></span>
                            </div>
                        </div>
                        <div class="col-10 mobile-right-info">
                            <h6><a href="<?=$user2[5]['url']?>"><?=mb_substr($user2[5]['title'],0,4,'utf-8')?></a></h6>
                            <p><?=mb_substr($user2[5]['description'],0,50,'utf-8')?></p>
                        </div>
                    </div>
                </div>

            </div>
            <!-- <div class="text-center">
                <a class="btn btn-style btn-primary mt-sm-5 mt-4 mr-2" href="#book"> View more advanced features</a>
            </div> -->
        </div>
        <!-- //mobile-info-->
    </div>
</section>
<!-- //mobile section --->

<!-- footer -->
<section class="w3l-footer-29-main">
    <div class="footer-29 py-5">
        <div class="container py-lg-4">
            <div class="row footer-top-29">
                <div class="col-lg-10 col-md-6 footer-list-29 footer-1 pr-lg-5">
                    <div class="footer-logo mb-4">
                        <a class="navbar-brand" href="<?=$xiadanurl?>">
                            <span class="iconfont iconhuojian1" style="color: #fff;"></span><?=mb_substr($user['title'],0,8,'utf-8')?></a>
                    </div>
                    <p><?=mb_substr($user2[0]['keywords'],0,50,'utf-8')?></p>
                    <p><?=mb_substr($user2[1]['keywords'],0,50,'utf-8')?></p>
                    <p><?=$juzi[1]?></p>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-5 col-5 footer-list-29 footer-2 mt-md-0 mt-5">
                </div>
            </div>
        </div>
    </div>
    
    
<div id="cc-myssl-id" style="position: fixed;right: 0;bottom: 0;width: 65px;height: 65px;z-index: 99;"> 
<img src="http://www.yuanxiapi.cn/apijs/引导页/myssl-id.png"  style="width:100%;height:100%" /></div>
    
    <!-- copyright -->
    <section class="w3l-copyright text-center" style="background-color: white !important;border-top:none !important;padding:0.6rem 0 !important;">
        <div class="container">
                 <p>
<HR>
         <center>
      <img src="<?=$tximg[0]?>" width="13%" style="max-width: 100%; border-radius: 70%;">
<img src="<?=$tximg[1]?>" width="13%" style="max-width: 100%; border-radius: 70%;">      
            
    <p>Copyright &copy; 2020-<?=date('Y')?> [<?=$_SERVER['HTTP_HOST']?>] <a style='color:#F4D03F' href="<?=$siteurl?>"><?=mb_substr($user['title'],0,10,'utf-8')?></a>·版权所有</p>
</center>
    
    <p><center>
 <?=$user['title']?><br>      
<? foreach($user2 as $row){ echo'<a href="'.$row['url'].'"  target="_blank">'.mb_substr($row['title'],0,10,'utf-8').'</a> | ';}?>
<br><?=$juzi[2]?>
</p> </center>
               

<? if($config['class_youlian']==1){ $yl_footer='<p name="'.$_SERVER['HTTP_HOST'].'"><center>友情链接：'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<a href="'.$yl_url.'" target="_blank">'.mb_substr($yl_name,0,5,'utf-8').'</a> | '; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</center></p>'; } ?>
<?=$config['article_footer']?>
		</div>
        <!-- move top -->
<button onclick="topFunction()" id="movetop" style="background-color: rgba(104, 104, 104, 0.49) !important; display: none;" title="Go to top"><?=$user['title']?></button>
        
        <!-- /move top -->
    </section>
    <!-- //copyright -->
</section>
 </body></html>
</div>


