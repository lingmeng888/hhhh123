<? if (strpos($_SERVER['PHP_SELF'],'template')!== false&&strpos($_SERVER['PHP_SELF'],'index.php')!== false){
  header("HTTP/1.1 404 Not Found");
  header("Status: 404 Not Found");  exit;} ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<title><?=$user['title']?></title>
  	<meta name="keywords" content="<?=$user['keywords']?>">
	<meta name="description" content="<?=$user['description']?>">
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/bootstrap.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/animate.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/style.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/normalize.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/cloudin.css" rel="stylesheet">

</head>
<body>
<div id="page"> <nav class="fh5co-nav" role="navigation" id="nav">
  <div class="top-menu">
    <div class="container">
      <div class="row">
        <div class="col-xs-6 col-sm-3">
          <div id="fh5co-logo"><a href="<?=$xiadanurl?>"target="_blank"><?=mb_substr($user['title'],0,4,'utf-8')?></a></div>
        </div>
        <div class="col-xs-6 col-sm-3" id="menu"> <img class="menu" src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/images/menu.png"> </div>
        <div class="col-xs-6 text-center menu-1 nav-center">
          <ul>
                      </ul>
        </div>

        <div  class="col-xs-6  menu-1 nav_right col-sm-3">
          <ul>
<li class="free-trial-btn fr"><a class="button" href="<?=$user2[0]['url']?>" target="_blank"><?=mb_substr($user2[0]['title'],0,4,'utf-8')?></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</nav>



<ul class="select" id="select" style="display:none;">
  </ul>

  <header id="fh5co-header" class="fh5co-cover" role="banner" style="" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container banner_text">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 text-center">
          <div class="display-t">
            <div class="display-tc animate-box">
              <h1><?=mb_substr($user['title'],0,6,'utf-8')?><span class="color00B3FF"></span></h1>
              <h1><?=$chengyu[0]?><span class="color00B3FF"></span></h1>
              <h2><?=$user['description']?></h2>
              <a class="button" href="<?=$xiadanurl?>" target="_blank"><?=$button[0]?></a>
              <a class="button1" href="<?=$xiadanurl?>" target="_blank"><?=$button[1]?></a></div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!--产品服务--> 
   
  <!--我们的优势-->
  <div class="our-advantage" id="advantage">
    <div class="container">
      <div class="section">
        <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
          <h2><?=mb_substr($user2[0]['title'],0,5,'utf-8')?></h2>
          <p><?=$user2[0]['description']?></p>
        </div>
        <ul class="advantage-list animate-box row">
          <li class="col-md-3 col-sm-6"> <span class="span1"> <img src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/images/jfzl.png"/> </span>
            <p class="p1"><?=mb_substr($user2[1]['title'],0,5,'utf-8')?></p>
            <p class="p2"><?=$user2[1]['description']?></p>
          </li>
          <li class="col-md-3 col-sm-6"> <span class="span1"> <img src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/images/fwyh.png"/> </span>
            <p class="p1"><?=mb_substr($user2[2]['title'],0,5,'utf-8')?></p>
            <p class="p2"><?=$user2[2]['description']?></p>
          </li>
          <li class="col-md-3 col-sm-6"> <span class="span1"> <img src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/images/kscl.png"/> </span>
            <p class="p1"><?=mb_substr($user2[3]['title'],0,5,'utf-8')?></p>
            <p class="p2"><?=$user2[3]['description']?></p>
          </li>
          <li class="col-md-3 col-sm-6"> <span class="span1"> <img src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/images/safe.png"/> </span>
            <p class="p1"><?=mb_substr($user2[4]['title'],0,5,'utf-8')?></p>
            <p class="p2"><?=$user2[4]['description']?></p>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <!---->
  <div id="delivery" class="intelligent-delivery" style="background:#fff;">
    <div class="container">
      <div class="row animate-box">
        <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
          <h2>交付流程</h2>
        </div>
      </div>
      <div class="row bs-wizard animate-box" style="border-bottom:0;">
        <div class="col-xs-3 bs-wizard-step complete">
          <div class="text-center bs-wizard-stepnum">
            <h4>场景沟通</h4>
          </div>
          <div class="progress">
            <div class="progress-bar"></div>
          </div>
          <a href="#" class="bs-wizard-dot"></a>
          <div class="bs-wizard-info text-center">
            <p>第一步</p>
          </div>
        </div>
        <div class="col-xs-3 bs-wizard-step active"><!-- complete -->
          <div class="text-center bs-wizard-stepnum">
            <h4>定制方案</h4>
          </div>
          <div class="progress">
            <div class="progress-bar"></div>
          </div>
          <a href="#" class="bs-wizard-dot"></a>
          <div class="bs-wizard-info text-center">
            <p>第二步</p>
          </div>
        </div>
        <div class="col-xs-3 bs-wizard-step disabled"><!-- complete -->
          <div class="text-center bs-wizard-stepnum">
            <h4>平台下单</h4>
          </div>
          <div class="progress">
            <div class="progress-bar"></div>
          </div>
          <a href="#" class="bs-wizard-dot"></a>
          <div class="bs-wizard-info text-center">
            <p>第三步</p>
          </div>
        </div>
        <div class="col-xs-3 bs-wizard-step disabled"><!-- active -->
          <div class="text-center bs-wizard-stepnum">
            <h4>数据交付</h4>
          </div>
          <div class="progress">
            <div class="progress-bar"></div>
          </div>
          <a href="#" class="bs-wizard-dot"></a>
          <div class="bs-wizard-info text-center">
            <p>第四步</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--免费试用-->
  <div id="fh5co-started">
    <div class="overlay"></div>
    <div class="container">
      <div class="row animate-box fadeInUp animated-fast">
        <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
          <h2><?=$chengyu[1]?></h2>
          <p><?=$juzi[0]?></p>
        </div>
      </div>
      <div class="row animate-box">
        <div class="col-md-8 col-md-offset-2 text-center">
          <p><a class="button" a href="<?=$xiadanurl?>" target="_blank"><?=$button[0]?></a></p></div>
        </div>
      </div>
    </div>
  </div>
  <div class="product">
    <div class="container">
      <div class="section">
        <div class="col-md-8 col-md-offset-2 text-center"><h2><?=$chengyu[2]?></h2>
           </div>
        <ul class="product-service-list animate-box clearfix " style="height: auto!important;">
                    <li> <a> <img src="<?=$siteurl.$yx_mulu?>template/15/uploads/allimg/190801/1-1ZP11615160-L.png" alt="伙伴六"> </a> </li>
                    <li> <a> <img src="<?=$siteurl.$yx_mulu?>template/15/uploads/allimg/190801/1-1ZP11615040-L.jpg" alt="伙伴五"> </a> </li>
                    <li> <a> <img src="<?=$siteurl.$yx_mulu?>template/15/uploads/allimg/190801/1-1ZP11614520-L.jpg" alt="伙伴四"> </a> </li>
                    <li> <a> <img src="<?=$siteurl.$yx_mulu?>template/15/uploads/allimg/190801/1-1ZP11614380-L.jpg" alt="伙伴三"> </a> </li>
                    <li> <a> <img src="<?=$siteurl.$yx_mulu?>template/15/uploads/allimg/190801/1-1ZP11614250-L.jpg" alt="伙伴二"> </a> </li>
                    <li> <a> <img src="<?=$siteurl.$yx_mulu?>template/15/uploads/allimg/190801/1-1ZP11614090-L.jpg" alt="伙伴一"> </a> </li>
                  </ul>
        <div class="product_bottom ">
          <div class="product_bottom_left">
         <img src="<?=$tximg[0]?>" alt="<?=$user['title']?>" width="12%" style="max-width: 100%; border-radius: 50%;">
          </div>
          <a class="button" href="<?=$xiadanurl?>" target="_blank"><?=$button[1]?></a> </div> 
      </div>
      
    <p class="desc"><center><?=$juzi[1]?></center></p>
      
    </div>
  </div>
  <!--底部--> 
  <footer id="fh5co-footer" role="contentinfo">
  <div class="container">
    <div class="row link">  <a href="#"><?=$chengyu[3]?></a>  <a href="#"><?=$chengyu[4]?></a>  <a href="#"><?=$chengyu[5]?></a>  </div>
    <div class="row copyright">
      <div class="col-md-12 text-center">
        <p> <small class="block">Copyright © 2002-<?=date('Y')?> <?=mb_substr($user['title'],0,10,'utf-8')?></small> </p>
<p><a class="block" href="<?=$user2[5]['url']?>" target="_blank"><?=$user2[5]['description']?></small> </p>
        <p> <? foreach($user2 as $row){ echo'<a href="'.$row['url'].'">'.mb_substr($row['title'],0,10,'utf-8').'</a> | ';}?></p>
        
<? if($config['class_youlian']==1){ $yl_footer='<p name="'.$_SERVER['HTTP_HOST'].'"><center>友情链接：'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<a href="'.$yl_url.'" target="_blank">'.mb_substr($yl_name,0,5,'utf-8').'</a> | '; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</center></p>'; } ?>
<?=$config['article_footer']?>
      </div>
    </div>
  </div>
</footer>
<!-- 应用插件标签 start --> 
 <!-- 应用插件标签 end --> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/jquery.min.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/yii.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/jquery.easing.1.3.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/dat.gui.min.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/jquery.waypoints.min.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/jquery.stellar.min.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/owl.carousel.min.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/jquery.magnific-popup.min.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/magnific-popup-options.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/main.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/yii.validation.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/yii.captcha.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/yii.activeform.js"></script> 
<script>
    jQuery(function ($) {
        var verify_placeholder = '';
        $(".product-service-list li .rsp").hide();
        $(".product-service-list li").hover(function(){
            $(this).find(".rsp").stop().fadeTo(500,0.9)
            $(this).find(".text").stop().animate({left:'0'}, {duration: 500})
        },function(){
            $(this).find(".rsp").stop().fadeTo(500,0)
            $(this).find(".text").stop().animate({left:'360'}, {duration: "fast"})
            $(this).find(".text").animate({left:'-360'}, {duration: 0})
        });

        var headH = document.documentElement.clientHeight
        $('.fh5co-cover').height(headH)


        $("#login-form").on("submit", function () {
            return false;
        });

        var obj = document.getElementById("nav");
        var ot = obj.offsetTop;
        document.onscroll = function () {
            var st = document.body.scrollTop || document.documentElement.scrollTop;
            obj.setAttribute("data-fixed",st > ot?"fixed":"")
        }



        if(window.location.href.indexOf('#') >-1){
            var anchors = window.location.href.split('#')[1];
            $('nav a').each(function(){
                if($(this).attr('href').indexOf('#') > -1){
                    if($(this).attr('href').split('#')[1] == anchors){
                        $(this).addClass('active');
                    }
                }
            })
        }

        
        var isShow = false;
        $('#menu').on('click',function(){
            isShow = !isShow;
            if( isShow ){
                $('#select').slideDown();
            }else{
                $('#select').slideUp();
            }
        });
        $('#homeform-verifycode').attr('placeholder', verify_placeholder)

        $('nav a').on('click',function(){
            $('nav a').removeClass('active');
            $(this).addClass('active');
        })
        
    });
    </script>
    
    
<style>
    #nav{ z-index: 100;}
    .product_right{ -webkit-flex: auto; -ms-flex: auto; flex: auto;}
</style>
<link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/contact.min.css" />
<ul class="contact-testin">
  <!-- pc -->
  <li class="visible-pc" id="qidian"> <i class="iconfont icon-QQQQQQQ"></i>
    <div class="contact-info">
      <p class="c-1">QQ</p>
      <p class="c-2">暂无</p>
    </div>
  </li>
   <li class="visible-pc"> <i class="iconfont icon-weixin"></i>
   <div class="contact-info">
      <p class="c-1">微信</p>
      <p class="c-2">暂无</p>
    </div>
  </li>
  <li class="back2top visible-pc" data-back2top="back2top"> <i class="iconfont icon-stick_icon"></i> </li>
</ul>

<link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/general.min.css" />
<link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/iconfont.min.css" />
<link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/consult.min.css" />
<link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/15/pc/skin/css/sweetalert.min.css" />
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/jquery.cookie.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/base.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/function.js"></script> 
<script src="<?=$siteurl.$yx_mulu?>template/15/pc/skin/js/sweetalert.min.js"></script>
<style type="text/css">
    #bsUl2{display:block;width:100%;position:absolute;background:#fff;z-index:1000;border:1px solid #ccc;top:39px;border-radius:0 0 2px 2px;padding:5px 0;right:94px; left:0;}
    #bsUl2 li{line-height:25px;padding:0 10px;list-style-type:none;}
    #bsUl2 li:hover{background-color:#e5f2ff;cursor:pointer}
</style>

<script>
    $("#cs-alert-box").click(function(e){
        if(!$(e.target).closest("#bsUl2").length) {
            $("#bsUl2").css("display","none");
        }
    });
    var chooseBs = function(obj) {
        $("#cs_company").val($(obj).text());
        $("#bsUl2").css("display","none");
    };
    var queryBsName = function(){
        var fullName = $.trim($("#cs_company").val());
        var content = "";
        if (fullName.length < 1) {
            return;
        } };
		 $(function(){
        var _csbox = $("#cs-alert-box"),
            _cssubmit = $("#cs_consult_submit"),
            _csform = $("#cs_consult_form"),
            _getcode = $("#cs_getcode"),

            _company = $('#cs_company'),
            _username = $('#cs_username'),
            _mobile = $('#cs_mobile'),
            _code = $('#cs_code'),
            _email = $('#cs_email'),

            _auth = $("#auth"),
            _url = $("#consult_url"),
            _service = $("#service_type"),
            _preferService = $("#preferService"),

            isNicheAuto = false, // 是否是自动弹出的商机表单
            isNicheClosed = false, // 用户关闭过自动弹出的商机弹窗或者提交成功之后不会再自动弹出，因为添加cookie时要新页面才生效，所以这里多在前端判断一层，避免表单关闭后，当前页还会一直触发弹窗的情况
            mobInterval, // 定时器
            timer, // 再次获取短信验证码的剩余时间
            analytics_url = window.location.protocol +"//"+ window.location.host + window.location.pathname; // 发送给统计后台的url
 $("[data-alert=consult]").click(function(){
            // 对隐藏的name="to"文本域进行赋值
            _service.val($(this).data("servicetype") || 1);
            _preferService.val($(this).attr("data-preferService"));
            // 对隐藏的name="consultUrl"文本域进行赋值
            isNicheAuto = false;
            _csbox.removeClass("cs-alert-auto"); // 隐藏商机自动弹窗的模块
             _csbox.fadeIn();
        });
 // 点击关闭弹窗
        _csbox.find(".icon-quxiao").click(function(){
            if(isNicheAuto && niche_modal_params.power){ // 未调用方法二 niche_modal_params.power 为undefined
                var expiresDate= new Date(); // 用户手动关闭的弹窗1小时之内不再提示
                expiresDate.setTime(expiresDate.getTime() + (60 * 60 * 1000));
                $.cookie('is_closed', 'yes', { expires: expiresDate, path: '/' });
                isNicheClosed = true;
            }

            closeNicheModal();
        });

        // 咨询提交之后显示用户注册的弹窗
        function showUserRegister(){
            swal({
               }, function(inputValue){
// 关闭按钮
                if (inputValue === false){
                    return false;
                }
                });
        }

        // 关闭弹窗
        function closeNicheModal(){
            _csbox.fadeOut(600, function(){
                isNicheAuto = false;
                _csbox.removeClass("cs-alert-auto");
            });
        }
});
</script>
</body>
</html>