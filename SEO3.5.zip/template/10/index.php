<? if (strpos($_SERVER['PHP_SELF'],'template')!== false&&strpos($_SERVER['PHP_SELF'],'index.php')!== false){
  header("HTTP/1.1 404 Not Found");
  header("Status: 404 Not Found");  exit;}?>
<!DOCTYPE html>
<html>
<html lang="en" class="no-js">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?=$user['title']?></title>
<meta name="keywords" content="<?=$user['keywords']?>">
<meta name="description" content="<?=$user['description']?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="stylesheet" type="text/css"  href="<?=$siteurl.$yx_mulu?>template/7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?=$siteurl.$yx_mulu?>template/7/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css"  href="<?=$siteurl.$yx_mulu?>template/7/css/style.css">

</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
    <!-- Navigation -->
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
            </div>
 
       
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                <ul class="nav navbar-nav">
                    <li class="hidden"><a href="#page-top"><?=mb_substr($user['title'],0,8,'utf-8')?></a></li>
<? foreach($user2 as $row){ $i++;if($i>4) break; echo' <li><a href="'.$row['url'].'">'.mb_substr($row['title'],0,8,'utf-8').'</a> </li>';}?>    
           
                </ul>
            </div>
        </div>
    </nav>



<!-- Header -->
    <header class="intro">
        <div class="intro-body">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <h2><span class="brand-heading"><?=mb_substr($user['title'],0,15,'utf-8')?></span></h2>
                        <br/>
                        <p class="intro-text"><?=$user['description']?></p><br/>
						<a href="<?=$xiadanurl?>" class="btn btn-primary"><h2><?=$button[1]?></h2></a>&nbsp;
							<a href="<?=$xiadanurl?>" class="btn btn-primary"><h2><?=$button[0]?></h2></a></h1>
						<br><p class="intro-text"><sub><?=$juzi[0]?></sub></p>
                    </div>
                </div>
            </div>
        </div>
    </header>

<!-- Services Section -->

<div id="services" class="text-center">
  <div class="container">
    <div class="section-title center">
      <h2><strong><?=trim($chengyu[0])?>-<?=mb_substr($user['title'],0,8,'utf-8')?></strong></h2>
     <img src="<?=$img[0]?>" width="15%" alt="<?=mb_substr($user['title'],0,10,'utf-8')?>">
      <hr>
    <p class="intro-text"><?=$user['keywords']?></p> 
      </div>



    <div class="row">
      <div class="col-md-3 col-sm-6 service"> <i class="fa fa-laptop"></i>
        <h4><strong><?=($user2[0]['title']?$user2[0]['title']:$chengyu[1])?></strong></h4>
        <p><?=($user2[0]['description']?$user2[0]['description']:$juzi[1])?></p>
      </div>
      <div class="col-md-3 col-sm-6 service"> <i class="fa fa-certificate"></i>
           <h4><strong><?=($user2[1]['title']?$user2[1]['title']:$chengyu[2])?></strong></h4>
        <p><?=($user2[1]['description']?$user2[1]['description']:$juzi[2])?></p>
      </div>
      <div class="col-md-3 col-sm-6 service"> <i class="fa fa-bullseye"></i>
            <h4><strong><?=($user2[2]['title']?$user2[2]['title']:$chengyu[3])?></strong></h4>
        <p><?=($user2[2]['description']?$user2[2]['description']:$juzi[3])?></p>
      </div>
    </div>
    
    <div class="row">
      <div class="col-md-3 col-sm-6 service"> <i class="fa fa-circle-o-notch"></i>
        <h4><strong><?=($user2[3]['title']?$user2[3]['title']:$chengyu[4])?></strong></h4>
        <p><?=($user2[3]['description']?$user2[3]['description']:$juzi[4])?></p>
      </div>
      <div class="col-md-3 col-sm-6 service"> <i class="fa fa-cog"></i>
           <h4><strong><?=($user2[4]['title']?$user2[4]['title']:$chengyu[5])?></strong></h4>
        <p><?=($user2[4]['description']?$user2[4]['description']:$juzi[5])?></p>
      </div>
      <div class="col-md-3 col-sm-6 service"> <i class="fa fa-life-ring"></i>
            <h4><strong><?=($user2[5]['title']?$user2[5]['title']:$chengyu[6])?></strong></h4>
        <p><?=($user2[5]['description']?$user2[5]['description']:$juzi[6])?></p>
      </div>
    </div>
    
  </div>
</div>



<nav id="footer">
  <div  class="container">
    <div class="pull-left fnav" >
        
        <center>
      <img src="<?=$tximg[0]?>" width="13%" style="max-width: 100%; border-radius: 70%;">
<img src="<?=$tximg[1]?>" width="13%" style="max-width: 100%; border-radius: 70%;">      
            
    <p>Copyright &copy; 2016-<?=date('Y')?> [<?=$_SERVER['HTTP_HOST']?>] <a style='color:#F4D03F' href="<?=$siteurl?>"><?=mb_substr($user['title'],0,10,'utf-8')?></a>·版权所有</p>
</center>
    
    <p><center>
 <?=$user['title']?><br>      
<? foreach($user2 as $row){ echo'<a href="'.$row['url'].'"  target="_blank">'.mb_substr($row['title'],0,10,'utf-8').'</a> | ';}?>
<br><?=$juzi[7]?>
</p> </center>
    
<? if($config['class_youlian']==1){ $yl_footer='<p name="'.$_SERVER['HTTP_HOST'].'"><center>友情链接：'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<a href="'.$yl_url.'" target="_blank">'.mb_substr($yl_name,0,5,'utf-8').'</a> | '; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</center></p>'; } ?>
<?=$config['article_footer']?>
    </div>
    <div class="pull-right fnav">
      
    </div>
  </div>
</nav>

          <div id="cc-myssl-id" style="position: fixed;right: 0;bottom: 0;width: 65px;height: 65px;z-index: 99;"> 
<img src="http://www.yuanxiapi.cn/apijs/引导页/myssl-id.png"  style="width:100%;height:100%" />
  </div>

<script src="<?=$siteurl.$yx_mulu?>template/7/js/modernizr-2.6.2.min.js"></script>
<script src="<?=$siteurl.$yx_mulu?>template/7/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="<?=$siteurl.$yx_mulu?>template/7/js/bootstrap.min.js"></script> 
<script>
 $(function()
 {
 var u = navigator.userAgent;
if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1||u.indexOf('iPhone') > -1||u.indexOf('Windows Phone') > -1||navigator.userAgent.indexOf("iPad")>-1) {
   $(".hover-bg .hover-text").css({'opacity':'1'});
   
   $(".hover-bg .hover-text>h4").css({'opacity':'1','-webkit-transform':'translateY(0)','transform':'translateY(0)'});
   
   $(".hover-bg .hover-text>i").css({'opacity':'1'});
} 
    
 });
</script>
</body>
</html>