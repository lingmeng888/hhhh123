<? if (strpos($_SERVER['PHP_SELF'],'template')!== false&&strpos($_SERVER['PHP_SELF'],'index.php')!== false){
  header("HTTP/1.1 404 Not Found");
  header("Status: 404 Not Found");  exit;}?>
<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<title><?=$user['title']?></title>
  	<meta name="keywords" content="<?=$user['keywords']?>">
	<meta name="description" content="<?=$user['description']?>">
<link href="<?=$siteurl.$yx_mulu?>template/1/static/bootstrap.min.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/1/static/font-awesome.min.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/1/static/animate.min.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/1/static/style.min.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/1/static/style-responsive.min.css" rel="stylesheet">
<link href="<?=$siteurl.$yx_mulu?>template/1/static/blue.css" id="theme" rel="stylesheet">
<!-- ================== END BASE CSS STYLE ================== -->
<!-- ================== END BASE CSS STYLE ================== -->

<!-- ================== BEGIN BASE JS ================== -->
<script src="<?=$siteurl.$yx_mulu?>template/1/static/pace.min.js"></script>
<!-- ================== END BASE JS ================== -->

</head>
<body data-spy="scroll" data-target="#header-navbar" data-offset="51" class=" pace-done"><div class="pace  pace-inactive hide"><div class="pace-progress" data-progress-text="100%" data-progress="99" style="width: 100%;">
  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>
    <!-- begin #page-container -->
    <div id="page-container" class="fade in">
        <!-- begin #header -->
        <div id="header" class="header navbar navbar-transparent navbar-fixed-top navbar-small">
            <!-- begin container -->
            <div class="container">
                <!-- begin navbar-header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#header-navbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="<?=$xiadan?>" class="navbar-brand">
                        <span class="brand-logo"></span>
                        <span class="brand-text">
                            <span class="text-theme"><?=mb_substr($user['title'],0,5,'utf-8')?></span>
                        </span>
                    </a>
                </div>
                <!-- end navbar-header -->

                <div class="collapse navbar-collapse" id="header-navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="#home" data-click="scroll-to-target"><?=mb_substr($user['title'],0,2,'utf-8')?>主页</a> </li>
                      	<li class=""><a href="#service" data-click="scroll-to-target"><?=mb_substr($user['title'],0,2,'utf-8')?>简介</a></li>
                        <li><a href="https://www.baidu.com/s?wd=site:<?=$_SERVER['HTTP_HOST']?>">百度<?=mb_substr($user['title'],0,2,'utf-8')?></a></li>
                        <li><a href="https://www.sogou.com/web?query=site:<?=$_SERVER['HTTP_HOST']?>">搜狗逛下</a></li>
                        <li><a href="<?=$xiadanurl?>">前往<?=mb_substr($user['title'],0,2,'utf-8')?></a></li>
                    </ul>
                </div>
                <!-- end navbar-collapse -->


            </div>
            <!-- end container -->
        </div>
        <!-- end #header -->

        
        <!-- begin #home -->
      <div id="home" class="content has-bg home" style="height: 744px;">
            <!-- begin content-bg -->
            <div class="content-bg">
                <img src="<?=$img[0]?>" winth="100%" height="150%" alt="<?=$user['title']?>" title="<?=$user['title']?>">
            </div>
            <!-- end content-bg -->
            <!-- begin container -->
            <div class="container home-content">
<h2><a href="<?=$xiadanurl?>"><?=mb_substr($user['title'],0,15,'utf-8')?></a></h2>
              <h3><?=$user['keywords']?></h3>
                <h4><?=$user['description']?>
                <br><a href="<?=$xiadanurl?>"><?=$juzi[0]?></a>
                </h4>
                
<a href="<?=$xiadanurl?>" class="btn btn-theme" style="background:black"><?=$button[0]?></a>&nbsp;<a href="<?=$xiadanurl?>" class="btn btn-outline"style="background:red"><?=$button[1]?></a><br>
<br><p><a href="JavaScript:;"><?=$chengyu[0]?></a></p>
            </div>
            <!-- end container -->
        </div>
        <!-- end #home -->
    
      <!-- beign #service -->
        <div id="service" class="content" data-scrollview="true">
            <!-- begin container -->
            <div class="container">
                <h2 class="content-title"><?=$chengyu[1]?></h2>
        <img src="<?=$img[1]?>"  height="200" width="100%">        
<p class="content-desc"><a href="<?=get_url()?>"><?=$user2[0]['keywords']?></a></p>
                
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
<div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-amazon"></i></div>
                            <div class="info">
                                <h4 class="title"><?=$user2[0]['title']?></h4>
                                <p class="desc"><?=$user2[0]['description']?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-automobile"></i></div>
                            <div class="info">
                                <h4 class="title"><?=$user2[1]['title']?></h4>
                                <p class="desc"><?=$user2[1]['description']?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-check-circle"></i></div>
                            <div class="info">
                                <h4 class="title"><?=$user2[2]['title']?></h4>
                                <p class="desc"><?=$user2[2]['description']?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-briefcase"></i></div>
                            <div class="info">
                                <h4 class="title"><?=$user2[3]['title']?></h4>
                                <p class="desc"><?=$user2[3]['description']?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-chrome"></i></div>
                            <div class="info">
                               <h4 class="title"><?=$user2[4]['title']?></h4>
                                <p class="desc"><?=$user2[4]['description']?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme bounceIn contentAnimated finishAnimated" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-hourglass"></i></div>
                            <div class="info">
                                <h4 class="title"><?=$chengyu[2]?></h4>
                                <p class="desc"><?=$juzi[1]?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                     </div>
                    
                
                    </div> </div>
                    <!-- end col-3 -->
                     
                    
<div class="col-md-4 col-sm-4 col-md-offset-4 col-sm-offset-4">
                        <!-- begin team -->
                        <div class="team">             
                            <div class="image flipInX contentAnimated finishAnimated" data-animation="true" data-animation-type="flipInX">
                            <img src="<?=$tximg[0]?>">
                              <img src="<?=$tximg[1]?>">
                            </div>
                        </div>
                        <!-- end team -->
<p class="content-desc"><center><a href="<?=$xiadanurl?>">支持多种支付方式：支付宝、QQ钱包、微信、财付通支付，可根据开发文档快速接入自己网站！</a></center></p>  
  <p class="content-desc"><img src="<?=$img[2]?>" alt="<?=$user['title']?>" height="200" width="100%">   </p>  
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
      
      
         <div id="team" class="content" data-scrollview="true">
            <!-- begin container -->
            <div class="container">
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4 col-md-offset-4 col-sm-offset-4">
                        <!-- begin team -->
                        <div class="team">             
                            <div class="image flipInX contentAnimated finishAnimated" data-animation="true" data-animation-type="flipInX">
                              <img src="<?=$tximg[2]?>" alt="<?=$user['title']?>">
                              <img src="<?=$tximg[3]?>" alt="<?=$user['title']?>">
                            </div>
                            <div class="info">

                                <div class="title text-theme"><?=mb_substr($user['title'],0,4,'utf-8')?>：<?=$juzi[2]?></div>
                               
                            </div>                     
                        </div>
                        <!-- end team -->
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
      
      
       
        <!-- begin #footer -->
        <div id="footer" class="footer">
            <div class="container">
                <div class="footer-brand">
                    <div class="footer-brand-logo"></div><?=mb_substr($chengyu[3],0,5,'utf-8')?></div>

                <p>
Copyright © 2016-<?=date('Y')?> <a href="<?=$xiadanurl?>" target="_blank"><?=mb_substr($user['title'],0,6,'utf-8')?></a> 版权所有.违者必究
<br><a href="<?=$siteurl?>"><?=get_url()?></a>                  
<br><? foreach($user2 as $row){ echo'<a href="'.$row['url'].'">'.mb_substr($row['title'],0,10,'utf-8').'</a> | ';}?><br></p>

<? if($config['class_youlian']==1){ $yl_footer='<p name="'.$_SERVER['HTTP_HOST'].'"><center>友情链接：'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<a href="'.$yl_url.'" target="_blank">'.mb_substr($yl_name,0,4,'utf-8').'</a> | '; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</center></p>'; } ?>
<?=$config['article_footer']?>
            </div>
        </div>
        <!-- end #footer -->
        
        
          <div id="cc-myssl-id" style="position: fixed;right: 0;bottom: 0;width: 65px;height: 65px;z-index: 99;"> 
<img src="http://www.yuanxiapi.cn/apijs/引导页/myssl-id.png"  style="width:100%;height:100%" />
  </div>
        
        <!-- begin theme-panel -->
        <div class="theme-panel">
            <div class="theme-panel-content">
                <ul class="theme-list clearfix">
                    <li><a href="javascript:;" class="bg-purple" data-theme="purple" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Purple" data-original-title="" title="">&nbsp;</a></li>
                    <li class="active"><a href="javascript:;" class="bg-blue" data-theme="blue" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Blue" data-original-title="" title="">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-green" data-theme="default" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Default" data-original-title="" title="">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-orange" data-theme="orange" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Orange" data-original-title="" title="">&nbsp;</a></li>
                    <li><a href="javascript:;" class="bg-red" data-theme="red" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Red" data-original-title="" title="">&nbsp;</a></li>
                </ul>
            </div>
        </div>
        <!-- end theme-panel -->
    </div>
    <!-- end #page-container -->

	<!-- ================== BEGIN BASE JS ================== -->
	<script src="<?=$siteurl.$yx_mulu?>template/1/static/jquery-1.9.1.min.js"></script>
	<script src="<?=$siteurl.$yx_mulu?>template/1/static/jquery-migrate-1.1.0.min.js"></script>
	<script src="<?=$siteurl.$yx_mulu?>template/1/static/bootstrap.min.js"></script>

	<script src="<?=$siteurl.$yx_mulu?>template/1/static/jquery.cookie.js"></script>
	<script src="<?=$siteurl.$yx_mulu?>template/1/static/scrollmonitor.js"></script>
	<script src="<?=$siteurl.$yx_mulu?>template/1/static/apps.min.js"></script>
	<!-- ================== END BASE JS ================== -->


<script>    
    $(document).ready(function() {
        App.init();
    });
</script>
</body>
</html>