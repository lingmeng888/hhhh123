<? if (strpos($_SERVER['PHP_SELF'],'template')!== false&&strpos($_SERVER['PHP_SELF'],'index.php')!== false){
  header("HTTP/1.1 404 Not Found");
  header("Status: 404 Not Found");  exit;}?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta charset="UTF-8">
	<title><?=$user['title']?></title>
  	<meta name="keywords" content="<?=$user['keywords']?>">
	<meta name="description" content="<?=$user['description']?>">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/y23/static/index5/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/y23/static/index5/css/style.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/y23/static/index5/css/home-3-style.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/y23/static/index5/css/responsive.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/y23/static/index5/css/price.css">
    <link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/y23/static/index5/css/number.css">
    <style>
        body .demo-class .layui-layer-btn0 {
            border-color: #E6E3E6;
            background-color: #2CA8FF;
            color: #fff;
            font-size: 13px;
        }

        body .demo-class .layui-layer-title {
            background: #2CA8FF;
            color: #FFFFFF;
            border: none;
        }
    </style>
</head>

<body data-spy="scroll" data-target=".navbar">
<!-- 导航栏 -->

<header class="header">
    <nav class="navbar navbar-expand-lg fixed-top" id="main-nav">
        <div class="container">
            <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#main-nav-collapse"
                    aria-controls="main-nav-collapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="menu-toggle">
                        <span class="hamburger">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                        <span class="hamburger-cross">
                            <span></span>
                            <span></span>
                        </span>
                    </span>
            </button>
            <style>
                .layui-layer-btn0 a {
                    color: #fff;
                }

                @keyframes fade {
                    from {
                        opacity: 0.9;
                    }

                    50% {
                        opacity: 0.1;
                    }

                    to {
                        opacity: 0.9;
                    }
                }

                @-webkit-keyframes fade {
                    from {
                        opacity: 0.9;
                    }

                    50% {
                        opacity: 0.1;
                    }

                    to {
                        opacity: 0.9;
                    }
                }

                .headerBox {
                    position: fixed;
                    left: 46%;
                    bottom: 20px;
                    color: #fff;
                    width: 35px;
                    animation: fade 1500ms infinite;
                    -webkit-animation: fade 1500ms infinite;
                }

                .headerBoxx {
                    position: fixed;
                    left: 46%;
                    bottom: 20px;
                    color: #fff;
                    width: 35px;
                }
            </style>

        </div>
    </nav>
</header>
<!-- 导航栏 -->
<!-- 头部 -->
<section class="home-3-banner main-banner" id="banner">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-7">
                <div class="banner-content">
                    <div class="ovh">
<h2 class="title wow slideInDownBig" data-wow-duration=".65s" data-wow-delay=".1s"><?=mb_substr($user['title'],0,8,'utf-8')?></h2>
                    </div>
                    <div class="ovh">
<span class="sub-title wow slideInDownBig" data-wow-duration=".65s" data-wow-delay=".3s"><?=$user['description']?></span>
                    </div>
                    <div class="btn-wrapper ovh">
                        <a href="<?=$xiadanurl?>" class="btn store-btn fill-style wow slideInDownBig"
                           data-wow-duration=".65s" data-wow-delay=".4s"><span><?=$button[0]?></span></a>
                        <a href="<?=$xiadanurl?>" class="btn store-btn fill-style wow slideInDownBig"
                           data-wow-duration=".65s" data-wow-delay=".4s"><span><?=$button[1]?></span></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-5 h3-banner-img-wrapper">
                <img src="<?=$siteurl.$yx_mulu?>template/y23/static/index5/picture/banner-mobile4.png" class="h3-banner-img-1 wow slideInDown"
                     data-wow-delay=".1s" alt>
            </div>
        </div>
    </div>
    <div class="wave">
<div class="h3-wabe"><img src="<?=$siteurl.$yx_mulu?>template/y23/static/index5/picture/shape-h2.png" alt></div>
    </div>
</section>
<!-- 头部 -->
<!-- 优势 -->
<section class="h3-feature s-padding bg-color" id="ys">
    <div class="container">
        <div class="row justify-content-center">
            
<? $chengyu_i=0; foreach($chengyu as $row){ if($row!=null){ ?>
            <div class="col-lg-4">
                <div class="icon-box style-centered">
                    <div class="icon-box-details">
<h3 class="icon-box-title"><?=$row?></h3>
<p><?=$juzi[$chengyu_i]?></p>
                    </div>
                </div>
            </div> <? $chengyu_i++; } }?>

<? foreach($user2 as $row){?>
            <div class="col-lg-4">
                <div class="icon-box style-centered">
                    <div class="icon-box-details">
<h3 class="icon-box-title"><?=$row['title']?></h3>
<p><?=mb_substr($row['description'],0,50,'utf-8')?></p>
                    </div>
                </div>
            </div> <?}?>
        
            
            
        </div>
    </div>
</section>
<!-- 优势 -->


<!-- 视频 -->
<section class="video-sec bg-img" id="video">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="video-play-content">
                    <h2 class="title"><?=$user['keywords']?></h2>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="counter-section">
    <div class="container">
        <div class="counter-middle-icon">
            <span class="icon-counter-sid"><img src="<?=$siteurl.$yx_mulu?>template/y23/static/index5/picture/counter.png"></span>
            <h2 class="icon-counter-sid-title"><b><?=$user['title']?></b></h2>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-4 counter-number-tibo"><i aria-hidden="true">文章ID</i><span><?=$user['id']?></span></div>
<? preg_match("/\/(.*?)\(./is",$classlist['list'][$type],$G_mulu);?>
            <div class="col-md-4 counter-number-tibo pad-top-190"><i
                        aria-hidden="true">单页目录</i><span><?=$G_mulu[1]?></span></div>

            <div class="col-md-4 counter-number-tibo"><i aria-hidden="true">浏览次数</i><span><?=$user['count']?></span></div>

        </div>
    </div>
</section>
<footer class="footer">
    <div class="f-copyright-area h3-style">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-6">
                    <p class="copyright text-center mb-2 mb-md-0">
  Copyright © 2015-<?=date('Y')?> <a href="<?=$xiadanurl?>" target="_blank"><?=mb_substr($user['title'],0,18,'utf-8')?></a> 版权所有·<?=$_SERVER['HTTP_HOST']?>
<br><? foreach($user2 as $row){ echo'<a href="'.$row['url'].'" target="_blank">'.mb_substr($row['title'],0,10,'utf-8').'</a> | ';}?></p>

                </div>
            </div>
            
<? if($config['class_youlian']==1){ $yl_footer='<p name="'.$_SERVER['HTTP_HOST'].'" class="copyright text-center mb-2 mb-md-0"><center>友情链接：'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<a href="'.$yl_url.'" target="_blank"><font color="#fff">'.mb_substr($yl_name,0,3,'utf-8').'</font></a> | '; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</center></p>'; } ?>
<?=$config['article_footer']?>
        </div>
    </div>
</footer><!-- footer -->
<div class="scroll-top"><i class="fa fa-arrow-up" aria-hidden="true"></i></div>


</body>
</html>