<? if(!defined('IN_CRONLITE'))exit();?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8"/>
<meta http-equiv="Cache-Control" content="no-transform"/>
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
<meta name="applicable-device" content="pc,mobile"/>
<meta http-equiv="Content-Language" content="zh-CN" />
	<title><?=$user['title']?></title>
  	<meta name="keywords" content="<?=$user['keywords']?>">
	<meta name="description" content="<?=$user['description']?>">
<meta name="author" content="<?=$siteurl?>" />
<link rel="stylesheet" type="text/css" href="<?=$siteurl.$yx_mulu?>template/25/style/style.css" media="screen"/>
<link rel="stylesheet" href="<?=$siteurl.$yx_mulu?>template/25/css/fontello.css" />
<style type="text/css">
.bodyOpen .logo a, .whitebg .logo a {background-image:url(<?=$siteurl.$yx_mulu?>template/25/img/logo-color.png);}
</style>
</style>
</style>
<script src="<?=$siteurl.$yx_mulu?>template/25/script/jquery-2.2.4.min.js" type="text/javascript"></script>



<link rel="stylesheet" type="text/css" href="<?=$siteurl.$yx_mulu?>template/25/css/owl.carousel.min.css" media="screen"/>
</head>
<body>
<header class="header">
	<div class="inner">

<h2><a href="<?=$siteurl?>" title="<?=mb_substr($user['title'],0,3,'utf-8')?>"><?=mb_substr($user['title'],0,4,'utf-8')?></a></h2>

				<div class="other">
			<span class="schbtn"><i class="icon-search"></i></span>
			<span class="navbtn"><i class="icon-menu"></i></span>
		</div>
		<nav class="nav">
			<ul>
				<li class="navbar-item cur"><a href="">首页</a>
<? foreach($user2 as $row){ $i++;if($i>5) break; echo' <li class="navbar-item"><a href="'.$row['url'].'">'.mb_substr($row['title'],0,4,'utf-8').'</a> </li>';}?>    

			</ul>
		</nav>
		</nav>

				</form>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</header>
<div id="slides" class="owl-carousel">
		<div class="item" style="background-image:url(<?=$siteurl.$yx_mulu?>template/25/img/202005261590491164244934.jpg);">
		<section class="inner">
			<h3><?=mb_substr($user['title'],0,15,'utf-8')?></h3>
			<div class="des">
				<pre><?=$user['description']?></pre>
			</div>
<div class="views"><a href="<?=$xiadanurl?>" title="点击咨询了解" target="_blank"><?=$button[0]?></a></div>
<div class="views">
<div class="views"><a href="<?=$xiadanurl?>" title="点击咨询了解" target="_blank"><?=$button[1]?></a></div>
</section></div>

		<div class="item" style="background-image:url(<?=$siteurl.$yx_mulu?>template/25/img/202005261590491164244934.jpg);">
		<section class="inner">
			<h3><?=mb_substr($user2[0]['title'],0,15,'utf-8')?></h3>
			<div class="des">
				<pre><?=$user2[0]['description']?></pre>
			</div>
<div class="views"><a href="<?=$xiadanurl?>" title="点击咨询了解" target="_blank"><?=$button[0]?></a></div>
<div class="views"><a href="<?=$xiadanurl?>" title="点击咨询了解" target="_blank"><?=$button[1]?></a></div>
		</section>
	</div>
	</div>
<div class="loading"></div>
<section class="service">
	<div class="inner">		
		<ul>
						<li>
				<a href="<?=$user2[1]['url']?>" title="<?=$user2[1]['title']?>">
					<figure class="thumbnail">
						<img src="<?=$siteurl.$yx_mulu?>template/25/img/202005211590058977105300.jpg" alt="<?=$user2[1]['title']?>"/>
					</figure>
					<h2><?=$user2[1]['title']?></h2>
				</a>			
			</li>
						<li>
				<a href="<?=$user2[2]['url']?>" title="<?=$user2[2]['title']?>">
					<figure class="thumbnail">
						<img src="<?=$siteurl.$yx_mulu?>template/25/img/202005211590058957173721.jpg" alt="<?=$user2[2]['title']?>"/>
					</figure>
					<h2><?=$user2[2]['title']?></h2>
				</a>			
			</li>
						<li>
				<a href="<?=$user2[3]['url']?>" title="<?=$user2[3]['title']?>">
					<figure class="thumbnail">
						<img src="<?=$siteurl.$yx_mulu?>template/25/img/202005211590058971161529.jpg" alt="<?=$user2[3]['title']?>"/>
					</figure>
					<h2><?=$user2[3]['title']?></h2>
				</a>			
			</li>
						<li>
				<a href="<?=$user2[4]['url']?>" title="<?=$user2[4]['title']?>">
					<figure class="thumbnail">
						<img src="<?=$siteurl.$yx_mulu?>template/25/img/202005211590058964336648.jpg" alt="<?=$user2[4]['title']?>"/>
					</figure>
					<h2><?=$user2[4]['title']?></h2>
				</a>			
			</li>
					</ul>
	</div>
</section>
<section class="about">	
	<div class="inner">
		<hgroup class="hmtitle">
			<h3>我们是谁</h3>
			<h4><span><?=$chengyu[0]?></span></h4>
		</hgroup>
						<div class="aboutpic">
			<div id="aboutpic" class="owl-carousel">
<div class="item"><img src="<?=$siteurl.$yx_mulu?>template/25/img/202006111591872192635546.jpg" alt="关于我们"></div>
<div class="item"><img src="<?=$siteurl.$yx_mulu?>template/25/img/202006111591872192779323.jpg" alt="关于我们"></div>
<div class="item"><img src="<?=$siteurl.$yx_mulu?>template/25/img/202006111591872193166805.jpg" alt="关于我们"></div>
							</div>
		</div>
				
		<div class="info"><div class="excerpt">
<p><?=$user2[1]['description']?>
<div><br><div></p>
<p><?=$user2[2]['description']?></p></div>
				
			<div class="more"><a href="<?=$xiadanurl?>" title="关于我们">了解更多+</a></div>
		</div>
	</div>
</section>
<section class="why">	
	<div class="inner">
		<hgroup class="hmtitle">
			<h3>为什么选择我们？</h3>
			<h4><span><?=$chengyu[1]?></span></h4>
		</hgroup>
		<ul>			
						<li>				
				<figure class="thumbnail">
					<img src="<?=$siteurl.$yx_mulu?>template/25/img/7ffdf3a2223d80969694.png" alt="实战派专业团队"/>
				</figure>
				<h5>软件之种类多</h5>
				<p>各种系统营销软件应有尽有。</p>				
			</li>
						<li>				
				<figure class="thumbnail">
					<img src="<?=$siteurl.$yx_mulu?>template/25/img/860e624684b1fc1da4ea.png" alt="安全保障的合作"/>
				</figure>
				<h5>安全保障的合作</h5>
				<p>每个软件都经过一系列的更新测试。</p>				
			</li>
						<li>				
				<figure class="thumbnail">
					<img src="<?=$siteurl.$yx_mulu?>template/25/img/c3efe96c7639c426350c.png" alt="全方位优化方案"/>
				</figure>
				<h5>全方位优化方案</h5>
				<p>收集反馈问题等待技术再次更新。</p>				
			</li>
						<li>				
				<figure class="thumbnail">
					<img src="<?=$siteurl.$yx_mulu?>template/25/img/6aae5b44bb1947e22fab.png" alt="专属一对一服务"/>
				</figure>
				<h5>专属一对一服务</h5>
				<p>您可以实时联系最新进展。</p>				
			</li>
					</ul>
	</div>
</section>
<section class="evaluate">	
	<div class="inner">
		<hgroup class="hmtitle">
			<h3>客户留言</h3>
			<h4><span><?=$chengyu[2]?></span></h4>
		</hgroup>
		<ul>				


<? $ui=0; foreach($tximg as $row){ if($row!=null){  ?>
<li><figure class="avatar"><img src="<?=$row?>" alt="访客"/></figure>
<div class="info"><div class="box"><i class="icon-quote-left"></i>
<div class="text"><?=$user2[$ui]['keywords']?></div><i class="icon-quote-right"></i>
</div></div></li>
 <?} $ui++; }?>
			
<li class="odd"><figure class="avatar"><img src="<?=$siteurl.$yx_mulu?>template/25/img/e6b72482c3327495661724856a44383c.png" alt="访客"/></figure>
<div class="info"><div class="box"><i class="icon-quote-left"></i>
<div class="text"><?=$juzi[0]?></div>
<i class="icon-quote-right"></i></div></div></li>

<li><figure class="avatar"><img src="<?=$siteurl.$yx_mulu?>template/25/img/e6b72482c3327495661724856a44383c.png" alt="访客"/></figure>
<div class="info"><div class="box"><i class="icon-quote-left"></i>
<div class="text"><?=$juzi[1]?></div>
<i class="icon-quote-right"></i></div></div></li>

<li class="odd"><figure class="avatar"><img src="<?=$siteurl.$yx_mulu?>template/25/img/e6b72482c3327495661724856a44383c.png" alt="访客"/></figure>
<div class="info"><div class="box"><i class="icon-quote-left"></i>
<div class="text"><?=$user2[3]['description']?></div>
<i class="icon-quote-right"></i></div></div></li>

</ul></div></section>


<div class="pageslist">
			<div class="inner">
			    
			    
<ul>
<? foreach($user2 as $row){ echo'<li><a href="'.$row['url'].'"  target="_blank">'.mb_substr($row['title'],0,10,'utf-8').'</a></li>';}?> </ul>


<? if($config['class_youlian']==1){ $yl_footer='<ul name="'.$_SERVER['HTTP_HOST'].'">'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<li><a href="'.$yl_url.'" target="_blank">'.mb_substr($yl_name,0,4,'utf-8').'</a></li>'; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</ul>'; } ?>


	</div></div>
	
	
		<div class="copyright">文章ID：<?=$user['id']?>，浏览次数：<?=$user['count']?>
<br><?=$config['article_footer']?>
<div class="inner"><font color="#F00000"><a href="<?=$siteurl?>">2015-<?=date("Y")?> @版权所有.<?=get_url()?></font></div>
</div>
</footer>
<script type="text/javascript" src="<?=$siteurl.$yx_mulu?>template/25/script/owl.carousel.min.js"></script>
<script type="text/javascript" src="<?=$siteurl.$yx_mulu?>template/25/script/leonhere.js"></script>
</body>
<script>
var _url = '/';
$(function(){	
	$(window).scroll(function(){
		var _scroll = $(window).scrollTop();
		if(_scroll > 0){
			$('.header').addClass('whitebg');
		}else{
			$('.header').removeClass('whitebg');
		}
	}).trigger('scroll');	
});	
</script>



  <script src="<?=$siteurl.$yx_mulu?>template/25/styles/js/jquery.min.js.html"></script>
  <style>
    .my_kefu {position: fixed;width: auto;top: 40%;right: 0px;z-index: 99;}
    .my_kefu ul {}
    .my_kefu ul li {background: #424242;width: 30px;height: 50px;margin-bottom: 10px;display: flex;flex-direction: column;justify-content: center;align-items: center;border-radius: 10px;padding: 0px 15px;}
    .my_kefu_item img {width: 20px;}
    .my_kefu_item {display: flex;align-items: center;justify-content: space-around;color: white;}
    .my_kefu ul li:hover {cursor: pointer;background: red;}
    .my_kefu_img {display: none;width: 140px;height: auto;position: absolute;right: 4rem;background: #424242;color: white;}
    .my_kefu_img img {width: 100%;}
    .my_kefu_hidden {display: none;flex-direction: row;justify-content: center;align-items: center;z-index: 999;height: 50px;border-radius: 10px;width: auto;background: red;color: #fff;padding: 0px 20px;}
    .my_kefu_hidden img {width: 20px;}
    .my_kefu_hidden a {display: flex;flex-direction: row;width: 90px;align-items: center;color: #fff;justify-content: center;}
    .my_kefu_hidden > div {display: flex;flex-direction: column;min-width: 120px;}
    .my_kefu ul li:hover .my_kefu_item {display: none;}
    .my_kefu ul li:hover .my_kefu_hidden {display: flex;flex-direction: row;text-align: center;position: absolute;right: 0px;}
    .my_kefu ul li:hover .my_kefu_img {display: flex;}
  </style>

 
<div class="my_kefu">
  <ul>

    <li> 
          <div class="my_kefu_item"><span><img src="<?=$siteurl.$yx_mulu?>template/25/img/ma.png"></span></div>
      <div class="my_kefu_hidden">
        <a href="<?=$xiadanurl?>" id="ma">
          <span><img src="<?=$siteurl.$yx_mulu?>template/25/img/ma.png"></span>
          <span>点击购买</span>
        </a>
      </div>
    </li>
    <li>  
      <div class="my_kefu_item"><span><img src="<?=$siteurl.$yx_mulu?>template/25/img/weixin.png"></span></div>
      <div class="my_kefu_hidden">
        <a href="" id="qq">
          <span><img src="<?=$siteurl.$yx_mulu?>template/25/img/weixin.png"></span>
          <span>微信：123456</span>
        </a>
      </div>
    </li>
    <li>
      <div class="my_kefu_item"><span><img src="<?=$siteurl.$yx_mulu?>template/25/img/qq.png"></span></div>
      <div class="my_kefu_hidden">
          <a href="" id="qq">
        <span><img src="<?=$siteurl.$yx_mulu?>template/25/img/qq.png"></span>
        <div>
          <span id="name1">QQ</span>
          <span id="phone">123456</span>
        </div>
      </div>
    </li>
