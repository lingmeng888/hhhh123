<?
if(!defined('IN_CRONLITE'))exit;

if(isset($_COOKIE["admin_token"])){
$session=md5($config['user'].$config['pwd'].$password_hash);
if($_COOKIE["admin_token"]===$session){ $islogin=1;  } }
