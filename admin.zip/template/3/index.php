<? if (strpos($_SERVER['PHP_SELF'],'template')!== false&&strpos($_SERVER['PHP_SELF'],'index.php')!== false){
  header("HTTP/1.1 404 Not Found");
  header("Status: 404 Not Found");  exit;}?>

<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<title><?=$user['title']?></title>
  	<meta name="keywords" content="<?=$user['keywords']?>">
	<meta name="description" content="<?=$user['description']?>">
	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
    <link rel="stylesheet" type="text/css" href="https://c.mipcdn.com/static/v2/mip.css">
	<link href="<?=$siteurl.$yx_mulu?>template/3/assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/3/assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/3/assets/css/animate.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/3/assets/css/style.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/3/assets/css/style-responsive.min.css" rel="stylesheet">
	<link href="<?=$siteurl.$yx_mulu?>template/3/assets/css/orange.css" id="theme" rel="stylesheet">
	<!-- ================== END BASE CSS STYLE ================== -->
    <style mip-custom>
    mip-nav-slidedown em{
        float: left;
        border: 15px solid;
        border-color: #DF8F19 #c47d15 #935e10;
        margin-right: 0px;
        margin-top: 25px;
        border-radius: 4px;
    }
    .home{
        height:815px;
    }
    mip-fixed{
        border-bottom: 1px solid rgba(255,255,255,.2);
    }
    mip-fixed[data-slide].mip-fixed-hide-top {
        -webkit-transform: translate3d(0,0,0);
        transform: translate3d(0,0,0);
        background-color:#fff;
        box-shadow: 0 1px 2px rgba(0,0,0,.2);
    }
    mip-nav-slidedown #bs-navbar a, mip-nav-slidedown #bs-navbar mip-link, mip-nav-slidedown #bs-navbar span{
        font-size:16px;
        font-weight:600;
        color:#8e8e8e;
    }
    mip-nav-slidedown .navbar-brand,mip-nav-slidedown #bs-navbar li.active a,mip-nav-slidedown #bs-navbar a:focus,mip-nav-slidedown #bs-navbar a:hover{
        color:#f59c1a!important;
    }
    mip-fixed[type=bottom], mip-fixed[type=top]{
        overflow: visible;
    }
    .content.has-bg .content-bg:before{
        z-index:999;
    }
    .content.has-bg .content-bg2:before{
        z-index:1;
    }
    .content.has-bg .container{
        z-index:999;
    }
    @media screen and (max-width: 767px){
        .mip-nav-wrapper {
            height:auto;
        }
        mip-nav-slidedown em{
            margin-top: 15px;
        }
        mip-fixed[type=bottom], mip-fixed[type=top]{
            height:60px;
        }
        .mip-nav-wrapper .navbar-toggle{
            border:1px solid #8F8E8E;
            margin-top:16px;
        }
        .mip-nav-wrapper #bs-navbar {
            background: rgba(0,0,0,.9);
        }
        .mip-nav-wrapper #bs-navbar .navbar-nav a, .mip-nav-wrapper #bs-navbar .navbar-nav mip-link, .mip-nav-wrapper #bs-navbar .navbar-nav span{
            text-align:left;
        }
        mip-nav-slidedown #bs-navbar .navbar-nav{
            padding:25px 15px;
        }
        .mip-nav-wrapper #bs-navbar .navbar-nav a, .mip-nav-wrapper #bs-navbar .navbar-nav mip-link, .mip-nav-wrapper #bs-navbar .navbar-nav span{
        padding:10px 0;
        font-size:16px;
        font-weight:600;
        color:#8F8E8E;
    }
    }
    @media (max-width: 1200px){
    .content.has-bg{background:url(<?=$img[0]?>) no-repeat 0 -50px;}
    .content.has-bg .content-bg2{background:url(<?=$img[0]?>) no-repeat 0 -50px;}
    .content.has-bg .content-bg img {
        max-height: 100%;
        max-width: inherit;
        display:none;
    }
    .content.has-bg .content-bg img {
        max-width: 100%;
    }
    }
</style>
</head>
<body data-spy="scroll" data-target="#header-navbar" data-offset="51">
    <!-- begin #page-container -->
    <div id="page-container">
        <!-- begin #header -->
        <mip-fixed type="top" data-slide>
            <div class="mip-nav-wrapper">
              <mip-nav-slidedown data-id="bs-navbar" class="mip-element-sidebar container" data-showbrand="1" data-brandname="<?=mb_substr($user['title'],0,4,'utf-8')?>">
                <em></em>
                <nav id="bs-navbar" class="navbar-collapse collapse navbar navbar-static-top">
                  <ul class="nav navbar-nav navbar-right">
                    <li class="active"><a href="#home" data-click="scroll-to-target"><?=mb_substr($user['title'],0,2,'utf-8')?>首页</a> </li>
                    <li><a href="#service" data-click="scroll-to-target"><?=mb_substr($user['title'],0,4,'utf-8')?></a></li>
                    <li><a href="#team" data-click="scroll-to-target"><?=mb_substr($user['title'],0,2,'utf-8')?>客服</a></li>
                    <li><a href="https://www.baidu.com/s?wd=site:<?=$_SERVER['HTTP_HOST']?>">百度<?=mb_substr($user['title'],0,2,'utf-8')?></a></li>
                    <li><a href="<?=$user2[0]['url']?>" target="_blank"><?=mb_substr($user2[0]['title'],0,4,'utf-8')?></a></li>
                    <li><a href="<?=$xiadanurl?>" target="_blank">加盟<?=mb_substr($user['title'],0,2,'utf-8')?></a></li>
                  </ul>
                </nav>
              </mip-nav-slidedown>
            </div>
        </mip-fixed>
        <!-- end #header -->
        
        <!-- begin #home -->
        <div id="home" class="content has-bg home">
            <!-- begin content-bg -->
            <div class="content-bg">
                <mip-img src="<?=$img[0]?>"></mip-img>
            </div>
            <!-- end content-bg -->
            <!-- begin container -->
            <div class="container home-content">
                <h1><?=$chengyu[0]?> <a href="<?=$xiadanurl?>"><?=mb_substr($user['title'],0,8,'utf-8')?></a></h1>
                <h3><?=mb_substr($user['keywords'],0,20,'utf-8')?></h3>
                <h4><?=$user['description']?><br>
                    <a href="<?=$xiadanurl?>"><?=$chengyu[0]?>、<?=$chengyu[1]?></a>
                </h4>
                
                <a href="<?=$xiadanurl?>" target="_blank" class="btn btn-theme"><?=$button[0]?></a> 
				<a href="<?=$xiadanurl?>" target="_blank" style="background:black" class="btn btn-outline"><?=$button[1]?></a><br>
				<p> <a href="<?=$xiadanurl?>"><?=$user['description']?></a></p>
            </div>
            <!-- end container -->
        </div>
        <!-- end #home -->
    	
      	<!-- beign #service -->
        <div id="service" class="content" data-scrollview="true">
            <!-- begin container -->
            <div class="container">
                <h2 class="content-title"><?=mb_substr($juzi[1],0,20,'utf-8')?></h2>
<p class="content-desc"><?=$user2[0]['keywords']?><br><mip-img src="<?=$img[1]?>" height="150" width="100%"></mip-img></p>
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-cog"></i></div>
                            <div class="info">
                                 <h4 class="title"><?=mb_substr($user2[0]['title'],0,15,'utf-8')?></h4>
                                <p class="desc"><?=mb_substr($user2[0]['description'],0,50,'utf-8')?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-paint-brush"></i></div>
                            <div class="info">
                                   <h4 class="title"><?=mb_substr($user2[1]['title'],0,15,'utf-8')?></h4>
                                <p class="desc"><?=mb_substr($user2[1]['description'],0,50,'utf-8')?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-file"></i></div>
                            <div class="info">
                                 <h4 class="title"><?=mb_substr($user2[2]['title'],0,15,'utf-8')?></h4>
                                <p class="desc"><?=mb_substr($user2[2]['description'],0,50,'utf-8')?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-code"></i></div>
                            <div class="info">
                               <h4 class="title"><?=mb_substr($user2[3]['title'],0,15,'utf-8')?></h4>
                                <p class="desc"><?=mb_substr($user2[3]['description'],0,50,'utf-8')?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-shopping-cart"></i></div>
                            <div class="info">
                                 <h4 class="title"><?=mb_substr($user2[4]['title'],0,15,'utf-8')?></h4>
                                <p class="desc"><?=mb_substr($user2[4]['description'],0,50,'utf-8')?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4">
                        <div class="service">
                            <div class="icon bg-theme" data-animation="true" data-animation-type="bounceIn"><i class="fa fa-heart"></i></div>
                            <div class="info">
                               <h4 class="title"><?=mb_substr($user2[5]['title'],0,15,'utf-8')?></h4>
                                <p class="desc"><?=mb_substr($user2[5]['description'],0,50,'utf-8')?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end #service -->

        <!-- begin #milestone -->
        <div id="milestone" class="content bg-black-darker has-bg" data-scrollview="true">
     
            <!-- begin content-bg -->
            <div class="content-bg content-bg2">
                <mip-img src="<?=$img[2]?>" alt="Milestone" title="<?=$user['title']?>"></mip-img></div>     
            <!-- end content-bg -->
            <!-- begin container -->      
            <div class="container"><center><p><?=$juzi[2]?></p></center>
                <!-- begin row -->             

                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4 milestone-col">
                        <div class="milestone">
                            <div class="number" data-animation="true"><?=$chengyu[3]?></div>
                            <div class="title"><?=$user2[1]['keywords']?></div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4 milestone-col">
                        <div class="milestone">
                          <div class="number" data-animation="true"><?=$chengyu[4]?></div>
                            <div class="title"><?=$user2[2]['keywords']?></div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4 milestone-col">
                        <div class="milestone">
                             <div class="number" data-animation="true"><?=$chengyu[5]?></div>
                            <div class="title"><?=$user2[3]['keywords']?></div>
                        </div>
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end #milestone -->
        
        <!-- begin #team -->
        <div id="team" class="content" data-scrollview="true">
            <!-- begin container -->
            <div class="container">
                <h2 class="content-title"><?=mb_substr($user['title'],0,10,'utf-8')?></h2>
                <p class="content-desc"><?=mb_substr($user['description'],0,25,'utf-8')?></p>
                <!-- begin row -->
                <div class="row">
                    <!-- begin col-3 -->
                    <div class="col-md-4 col-sm-4 col-md-offset-4 col-sm-offset-4">
                        <!-- begin team -->
                        <div class="team">             
                            <div class="image" data-animation="true" data-animation-type="flipInX">
                                <mip-img src="<?=$tximg[0]?>" alt="<?=$user['title']?>"></mip-img>
                            </div>
                            <div class="info">
                                <h3 class="name"><?=$chengyu[6]?></h3>
                                
                                <p><?=$juzi[6]?></p>
   
                            </div>                     
                        </div>
                        <!-- end team -->
                    </div>
                    <!-- end col-3 -->
                </div>
                <!-- end row -->
            </div>
 
             
            <!-- end container -->
        </div>
        <!-- end #team -->
      
        <!-- begin #footer -->
        <div id="footer" class="footer">
            <div class="container">
                <div class="footer-brand">
                    <div class="footer-brand-logo"></div>
                   <?=mb_substr($user['title'],0,8,'utf-8')?>
                </div>
                <p>
                <? foreach($user2 as $row){ echo'<a href="'.$row['url'].'">'.mb_substr($row['title'],0,10,'utf-8').'</a> | ';}?>    <br>
                   <span>资源来自互联网,如有侵权,不妥之处,请邮件联系我们，并出示版权证明以便删除</span>
<br><span><a href="<?=$xiadanurl?>">Copyright <?=date("Y")?> <?=mb_substr($user['title'],0,8,'utf-8')?> . <?=$siteurl?></a></span><br>
<a href="<?=$siteurl?>"><?=$juzi[7]?></a>
                </p>
                
                
<? if($config['class_youlian']==1){ $yl_footer='<p name="'.$_SERVER['HTTP_HOST'].'"><center>友情链接：'; 
$class = $DB->query("SELECT * FROM `seo_classlist` ORDER BY `sort` ASC");
$class_num = $DB->query("SELECT count(*) from seo_classlist where 1")->fetchColumn();
if($class_num!=0){ $yl_id=$id; $max_ylid=round($yl_id+($class_num*3));
$yl_titless=$DB->query("SELECT * FROM `seo_article` WHERE `id` >'{$yl_id}' and `id`<='$max_ylid'  and `active`=1 LIMIT ".$class_num); 
while($yl_titles = $yl_titless->fetch()){ $yl_title[]=$yl_titles; } 

$qz=str_replace(get_host($_SERVER['HTTP_HOST']) ,'',$_SERVER['HTTP_HOST']); //获取域名前缀
if($qz!=null&&$qz!='www.'){ $qz='www.'; }
$i=1; while($class_list = $class->fetch()){

$class_list['list']=unserialize($class_list['list']);
if($class_list['list']!=null&&is_array($class_list['list'])){
$count_list=@count($class_list['list'])-1;
$danye_url_type=rand(0,$count_list); }

$length = round(strlen($class_list['host'])*10+$class_list['id']+$id);
$yl_url="http://".$qz.$class_list['host'];

if($class_list['list'][$danye_url_type]!=null){ $yl_url.=str_ireplace('(.[0-9]*)',$length, $class_list['list'][$danye_url_type]);  }

$yl_name=$yl_title[$i]['title'];
if($yl_name!=null){ $yl_footer.='<a href="'.$yl_url.'" target="_blank">'.mb_substr($yl_name,0,5,'utf-8').'</a> | '; }
$i++; } unset($i,$yl_title);
} echo $yl_footer.'</center></p>'; } ?>
<?=$config['article_footer']?>
            </div>

        </div>
        <!-- end #footer -->
        
        <!-- begin theme-panel -->
        <div class="theme-panel">
            <a href="#" data-click="theme-panel-expand" class="theme-collapse-btn fade"><i class="fa fa-cog"></i></a>
            <div class="theme-panel-content">
                <ul class="theme-list clearfix">
                    <li><a href="#" class="bg-purple" data-theme="purple" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Purple">&nbsp;</a></li>
                    <li class="active"><a href="#" class="bg-blue" data-theme="blue" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Blue">&nbsp;</a></li>
                    <li><a href="#" class="bg-green" data-theme="default" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Default">&nbsp;</a></li>
                    <li><a href="#" class="bg-orange" data-theme="orange" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Orange">&nbsp;</a></li>
                    <li><a href="#" class="bg-red" data-theme="red" data-click="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Red">&nbsp;</a></li>
                </ul>
            </div>
        </div>
        <!-- end theme-panel -->
    </div>
    <!-- end #page-container -->

    <!--mip 运行环境-->
    <script src="https://c.mipcdn.com/static/v2/mip.js"></script>
    <script src="https://c.mipcdn.com/static/v2/mip-nav-slidedown/mip-nav-slidedown.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-share/mip-share.js"></script>
    <script src="https://c.mipcdn.com/static/v1/mip-stats-baidu/mip-stats-baidu.js"></script>
</body>
</html>

